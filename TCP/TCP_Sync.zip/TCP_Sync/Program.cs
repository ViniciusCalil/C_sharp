﻿using System;
using System.Text;    //---- for 'Enconding' (and derived) class(es)
using System.Security;    //---- for 'SecurityException'
using System.IO;    //---- for 'FileNotFoundException'
using System.Threading;
//---- for DNS name resolution
using System.Net;
using System.Net.Sockets;


namespace TCP_Sync {

    // A complete SOCKET is a combination of: a (set of) Comunication Protocol(s) and the Source and Destination 
    // set of Address (device address and service port for both Client and Server device hosts).
    // A socket is made complete only when a connection (with methods 'Connect()', 'Accept()', etc) 
    // is established. The complete socket is found inside the frame of each packet/datagram transmited and is
    // the only information necessary to individually identify any running communication between two devices.

    // To simplify the review of this program, a comment at the end of this source file show a resume 
    // of processes involved in TCP communication with sockets, for both client and server devices.

    // A few tests were executed to verify the behaviour of 'Socket.Send()' and 
    // 'Socket.Receive()' methods with respect to: capacity of maximum size of transfered 
    // data block in a single call of 'Socket.Send()' and capacity of 'Socket.Receive()' 
    // to identify (inside its Networ Interface Card reception buffer) distinct data blocks
    // sent (each one) in a distinct 'Socket.Send()' call.
    // The results from these tests shown that distinct data blocks (each one) from a distinct
    // 'Send()' call are not distinguished by the 'Receive()' call. To verify it:
    //    * at sender side, make two 'Send()' call, with first data block sent with size 
    //      50 and second with size 64000;
    //    * AFTER THAT, at receiver side, make two 'Receive()' call, with first buffer size equals  
    //      to 64000 and second buffer size equal to 50 (reciprocal of data block size sent);
    // Other result is that a single 'Send()' call can transfere at least 64*1024*1024 bytes. 
    // No tests were done with packet size larger that 64 MBytes. This packet size was transmitted
    // successfuly in Windows 7, but not in Linux Ubuntu (with Mono).
    // This facts shows that the receiver must follow the same procedure/protocol of the 
    // sender to define: the amount and sequence of data blocks (tranfered files or comand
    // strings), and also, the size of each individual data block. Otherwise, the receiver
    // will not realise if there is one or more distinct data block in its recption buffer.
    //
    // Classes "TCP_Client_Sync" and "TCP_Server_Sync" have Customized Time-Out for SEND and 
    // RECEIVE operations. To use this Customized Time-Out with time precision, the 
    // parameters "Socket.ReceiveTimeout" and "Socket.SendTimeout" must be set to zero.
    // This configuration (set parameters to zero) is NOT an obligation, if their value
    // are different from zero, the interval to Cusomized Time-Out expires will be increased
    // by intervals spend all times that "Socket.Send()" and "Socket.Receive()" time-out expire.
    // This Customized Time-Out may work in three different ways, based in the case that the 
    // transmitted data block is splitted by TCP protocol (in a lot of packets) and a "long" delay
    // has  occurred in delivering one packet. In this case, Customized Time-Out may work as following
    //     * measure time interval only between the call of the method that uses "Socket.Receive()"
    //       or "Socket.Send()" and the call of those 'Socket' class methods. If a delay happen to
    //       some packet time-out autmatically expires.
    //     * measure time interval between the call of the method that uses "Socket.Receive()"
    //       or "Socket.Send()" and the call of those 'Socket' class methods added to any delay
    //       that may happen to some packet. - Default mode -
    //     * measure time interval between the call of the method that uses "Socket.Receive()"
    //       or "Socket.Send()" and the call of those 'Socket' class methods and also any delay
    //       that may happen to some packet, but reset time interval any time that "Socket.Send()"
    //       or "Socket.Receive()" return some data.

        
        //     * measure time interval between the call of the method that implements "Socket.Receive()"
    //       or "Socket.Send()" added to any delay that may happen to some packet. - Default mode -
    //       


    static class TCPinfo {
        static public uint Eth_header { get { return 0; } }      // Size of the Ethernet frame header is 30 octets.
        static public uint Eth_pl_minTU { get { return 46; } }   // Minimum Ethernet Payload Size is 46 octets (plus a 30 octets header).
        static public uint Eth_pl_maxTU { get { return 1500; } } // Maximum Ethernet Payload Size is 1500 octets (plus a 30 octets header).
        static public uint Tcp_pl_maxTU { get { return 64 * 1024; } } // Maximum TCP Payload Size is 1500 octets (plus a 30 octets header).
        static public uint Tcp_hd_min { get { return 20; } }     // Minimum TCP Header Size is 20 octets.
        static public uint Tcp_hd_max { get { return 60; } }     // Maximum TCP Header Size is 60 octets.
        static public uint Udp_header { get { return 8; } }      // UDP Header Size is 60 octets.
    }

    class TCP_Client_Sync {
        private string ServerName = null; //The name of a server which provides the service desired, like: www.google.com.br, www.microsoft.com.br
        private IPAddress[] SrvIpAd = null;   // Array of IP addresses of the server in which this Client want to connect with.
        private ushort ServicePort = 4321; // Server will be listen this port. I. e., waiting for clients requesting for connection at this port.

        public Socket ClientSocket; //This is the Client socket that will connect to a remote/local 'service' (i.e. "subroutines/functions" inside a "program" that is(are) intended to answer the requests from other programs).
        private IPEndPoint ipep;  // The combination of network address and service port is defined by EndPoint class. For 'AddressFamily.InterNetwork'

        private bool IPv4_priority = true; // Try to connect using server IPv4 addresses before try IPv6 ones.

        private int SendReTryLim = 5;  // Number of times that Socket will try to send a message in a single call to 'ClientSEND()' method.
        private int SendReTryInterval = 2000;  // Number of miliseconds between each "send try" in a single call to 'ClientSEND()' method.
        private int ReceiveReTryLim = 6;  // Number of times that Socket will try to receive a message in a single call to 'ClientSEND()' method.
        private int ReceiveReTryInterval = 3000;  // Number of miliseconds between each "receive try" in a single call to 'ClientSEND()' method.



        public TCP_Client_Sync() {
            #region "User_sets_up_operation_mode_&_remote_service/clienthost_address_&_port"
            Console.WriteLine("\nEnter the SERVER's name (if it is logged on your DNS server) or IP address which you want to connect:");
            try {
                ServerName = Console.ReadLine();
                SrvIpAd = DNS_Resolver.Call_DNS_Resolver(ServerName);
            } catch (Exception) {
                SrvIpAd = new IPAddress[] { IPAddress.Parse("127.0.0.1") };
            }

            Console.WriteLine("\nEnter the PORT number of the SERVICE you want to connect:");

            string aux = null;
            try {
                aux = Console.ReadLine();
                if ((aux != null) && (aux.Trim() != string.Empty)) { // If user do not enter a valid string, let 'ServicePort' with default value. 
                    if (!ushort.TryParse(aux, out ServicePort))
                            ServicePort = 54321;
                }
            } catch (Exception) {
                ServicePort = 23451;
            }
            #endregion

            if (ClientConnection() == true) {
                System.Random rndnumb = new System.Random();

                byte[] msg1 = new byte[1023 * TCPinfo.Tcp_pl_maxTU]; 
                rndnumb.NextBytes(msg1); // Fill buffer 'msg1' with random data.

                if (ClientSEND(msg1) == msg1.Length) { Console.WriteLine("CLIENT SEND success.");

                    //Console.WriteLine("Press any key to send data to server.");
                    //Console.Read(); // Console.WriteLine("Int code from key pressed: {0}", Console.Read());
                    //byte[] msgB = new byte[TCPinfo.Eth_pl_minTU];
                    //rndnumb.NextBytes(msgB); // Fill buffer 'msgB' with random data.
                    //if (ClientSEND(msgB) == msgB.Length) { Console.WriteLine("CLIENT SEND success at second time."); }  // Used only while in tests for capacity of 'Socket.Receive()' to distinguishe distinct data blocks.

                    byte[] msg2 = new byte[msg1.Length];
                    if (ClientRECEIVE(msg2) == msg1.Length) { Console.WriteLine("CLIENT RECEIVE success."); }

                    int k = 0;
                    int klim = msg1.Length;
                    for (; (k < klim) && (msg1[k] == msg2[k]); ++k) ; // Count the number of elements that has the same value, in respective index position, among 'msg1' and 'msg2'.
                    if (k == msg1.Length) { Console.WriteLine("CLIENT received the SAME DATA BLOCK it sent to Server, successfully."); }

                    /* byte[] ReceivedMsg = null;
                     if (ClientRECEIVE(ReceivedMsg, TCP_Payload_small.Length) == TCP_Payload_small.Length) {
                         Console.WriteLine("CLIENT RECEIVE success.");
                     } else {
                         Console.WriteLine("Failure while Client were RECEIVING data FROM Server.");
                     }
                     */
                } else {
                    Console.WriteLine("Failure while SENDING data FROM Client TO Server.");
                    ClientReleaseComm();
                }

                /*
                string FileName = null;
                // FileName = "%userprofile%\\Documents\\zztestfile.dat";  // For Windows OS.
                FileName = "~/Documents/zztestfile.dat";  // For Linux OS.
                ClientSENDFILE(FileName);
                */

                Console.WriteLine("Press ENTER key to Shutdown and Close Connection of this client with server." + ipep.Address.ToString());
                Console.Read();
                ClientReleaseComm();
            }

        }


        public bool ClientConnection() {
            #region "CREATE SOCKET"
            if ((SrvIpAd?.Length ?? 0) > 0) {
                try {
                    ClientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    //  A Socket must be initialized with Transport and Network Protocols information (".NET" uses three Enums for this AddressFamily, SocketType and ProtocolType).
                    // AddressFamily Enum has fields: InterNetwork (for IP v4), InterNetworkV6 (for IP v6), AppleTalk, Ccitt (for X.25), Ipx, Unix, Unknown, etc.
                    // SocketType Enum defines properties of used Protocols (connection-oriented, message-oriented, connectionless, duplicated/out of order packets arrive).
                    // SocketType Enum has fields: Raw (to acces underlying transport protocol (providing a complete IP header) or protocols: ICMP, IGMP), 
                    //        Dgram (for UDP), Stream (for TCP), Unknown, etc. 
                    // ProtocolType Enum has fields: IPv4, IPv6, Raw, Ipx, Tcp, Udp, Unknown, etc.
                    // Trying to create a Socket with an incompatible combination (of SockteType and ProtocolType) throws a SocketException.
                    // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.socket?view=netframework-4.7.2
                } catch (SocketException e) {  // Combination of addressFamily, socketType, and protocolType results in an invalid socket.
                    Console.WriteLine("Failure while defining Communications Protocols. :: " + e.Message);
                    Console.WriteLine("Connection cannot be initialized without a Protocol.");
                    return false;
                }
            } else {
                Console.WriteLine("Connection cannot be initialized without an End Point (remote host address).");
                return false;
            }

            try {
                ClientSocket.ReceiveTimeout = 500; // The time-out value to synchronous 'Socket.Receive()' call, in milliseconds. The default value is 0, which indicates an infinite time-out period.        
                ClientSocket.SendTimeout = 500; // The time-out value to synchronous 'Socket.Send()' call, in milliseconds. The default value is 0, which indicates an infinite time-out period. Value between 1 and 499 will be changed to 500.
                ClientSocket.Blocking = true; // If you want execution to continue (without blocking current thread) even though the requested operation ('Connect', 'Send', 'Receive') is not complete, change the Blocking property to false. The 'Socket.Blocking' property should be set to true for TCP protocol to avoid Exceptions.
                // ClientSocket.DualMode = true;  // The Socket is a dual-mode socket used for both IPv4 and IPv6. No Exception is thrown.
                // ClientSocket.Ttl = 42;  // Set the Time To Live (TTL) to 42 router hops.
                // ClientSocket.ExclusiveAddressUse = true; // Set to 'true' if the Socket allows only one socket to bind to a specific port;
                // ClientSocket.NoDelay = false;   // Set 'false' if the Socket uses the Nagle algorithm. The Nagle algorithm is designed to reduce network traffic by causing the socket to buffer small packets and then combine and send them in one packet under certain circumstances. Setting this property on a User Datagram Protocol (UDP) socket will have no effect.
                // ClientSocket.SendBufferSize = 8192;  // Larger buffer might delay the recognition of connection difficulties. Consider increasing the buffer size if you are transferring large files, or you are using a high bandwidth, high latency connection (such as a satellite broadband provider.)
                // ClientSocket.ReceiveBufferSize = 8192; // Larger buffer potentially reduces the number of empty acknowledgements (TCP packets with no data portion), but might also delay the recognition of connection difficulties.
                // try {
                //     ClientSocket.LingerState = new LingerOption(true, 3); // For connection-oriented protocol (TCP). It specify a custon amount of time (in seconds) that the Socket will attempt to transmit remaining unsent data after 'Close()' or 'Disconnect()' methods has been called.
                //     // If 'LingerOption' is set to 'false' Socket will try to send remaining unsent data until default IP protocol time-out expires.
                //     // When the LingerTime property stored in the LingerState property is set greater than the default IP protocol time-out, the default IP protocol time-out will still apply and override.
                // } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                //     Console.WriteLine("SocketException while defining LingerState property. :: " + e.Message);
                // } catch (ObjectDisposedException e) {  // Socket has been closed.
                //     Console.WriteLine("ObjectDisposedException while defining LingerState property. :: " + e.Message);
                // }


            } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                Console.WriteLine("SocketException while defining Socket properties. :: " + e.Message);
            } catch (ObjectDisposedException e) {  // Socket has been closed.
                Console.WriteLine("ObjectDisposedException while defining Socket properties. :: " + e.Message);
            } catch (ArgumentOutOfRangeException e) { // The property value is invalid.
                Console.WriteLine("ArgumentOutOfRangeException while defining Socket properties. :: " + e.Message);
            } catch (InvalidOperationException e) {  // Bind(EndPoint) has been called for this Socket.
                Console.WriteLine("InvalidOperationException while defining Socket properties. :: " + e.Message);
            } catch (NotSupportedException e) {  // The "Ttl" property can be set only for sockets in the InterNetwork or InterNetworkV6 families
                Console.WriteLine("NotSupportedException while defining Socket properties. :: " + e.Message);
            }
            #endregion

            #region "CONNECT_TO_SERVER"
            bool Has_IPv6 = false;     // This variable is used only to try to connect to server using IPv4 addresses before IPv6.
            byte IP_Tests_phase = 0;    // This variable is used only to try to connect to server using IPv4 addresses before IPv6. Value '0' means IPv4 tests phase; '1' means IPv6 tests phase.
            bool ScktConnected = false;  // This flag is set when connection is confirmed, to "break" the loop, avoiding a new connection try with a different IP address from 'SrvIpAd'.

CONNECTION_PROC:   // This label is used only to try to connect to server using IPv4 addresses before IPv6.
            foreach (IPAddress address in SrvIpAd) {
                if ((IPv4_priority == true)) {
                    if (IP_Tests_phase == 0) { // The first time this 'foreach'  loop is executed, only IPv4 address will be tryed (to connect to server).
                        if (address.AddressFamily != AddressFamily.InterNetwork) {
                            Has_IPv6 = true;
                            continue;
                        }
                    } else { // (IP_Tests_phase == 1) In the second time this 'foreach' loop is executed, only IPv4 is NOT tryed (to connect to server).
                        if (address.AddressFamily == AddressFamily.InterNetwork) continue;
                    }
                }

                ipep = new IPEndPoint(address, ServicePort);


                try {
                    int ClientLocalPortNumber = 33333;
                    IPAddress ClientLocalIP = IPAddress.Any;//  IPAddress.Parse("192.168.0.10");
                    ClientSocket.Bind(new IPEndPoint(ClientLocalIP, ClientLocalPortNumber));
                    // The 'Bind()' method defines which address and port will be used by the client to request 
                    //     servers for connection.
                    // A call to 'Bind()' method, before calling 'Connect()' method, ONLY is necessary if the  
                    //     client will use JUST ONE SPECIFIC IPEndPoint to comunicate with the servers, instead of all its addresses.
                    // If it is not important which local address is assigned/binded to this Client,
                    //     create an IPEndPoint using 'IPAddress.Any' (0.0.0.0) as the address 
                    //     parameter, to bind on all network interface address.
                    //     To include all IPv6 and IPv4, use: "var listener = new TcpListener(IPAddress.IPv6Any, port); listener.Server.SetSocketOption(SocketOptionLevel.IPv6, SocketOptionName.IPv6Only, false);"
                    //     To include more than one IP address but NOT all, a new 'ServiceListeningSocket' must be created to each IP address to 'Bind()'.
                    // If it is not important which local PORT is used, create an 'IPEndPoint' using 0 for port
                    //     number, so system will assign an available port number between 1024 and 5000.
                    // If a UDP socket wants to receive interface information on received packets, the 'SetSocketOption()'
                    //     method should be explicitly called with the socket option set to 'PacketInformation' 
                    //     immediately after calling the 'Bind()' method. 
                    // To receive multicast datagrams, call 'Bind()' method with a multicast port number.
                    // Call 'Bind()' method to receive connectionless (UDP) datagrams using 'ReceiveFrom()' method.

                } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                    // Use the 'SocketException.ErrorCode' property to obtain the specific error code. Refer to the
                    //     "Windows Sockets" version 2 API error code documentation in the MSDN library for a detailed
                    //     description of the error.
                    Console.WriteLine("SocketException while BINDING address and port in which this client will request connections. :: " + e.Message);
                } catch (ObjectDisposedException e) {  // Socket has been closed.
                    Console.WriteLine("ObjectDisposedException while BINDING address and port in which this client will request connections. :: " + e.Message);
                } catch (ArgumentNullException e) {  // The IPEndPoint is null.
                    Console.WriteLine("ArgumentNullException while BINDING address and port in which this client will request connections. :: " + e.Message);
                } catch (SecurityException e) { // A caller higher in the call stack does not have permission for the requested operation.
                    Console.WriteLine("SecurityException while BINDING address and port in which this client will request connections. :: " + e.Message);
                } catch (FormatException e) { // Bad Format in 'IPAddress.Parse()'  string parameter.
                    Console.WriteLine("FormatException while BINDING address and port in which this client will request connections. :: " + e.Message);
                }
                if (ClientSocket.IsBound != true)
                    Console.WriteLine("It was not possible to select the local IPEndPoint of this Client on which connections will be request.");

                try {
                    ClientSocket.Connect(ipep); // 
                    // If the socket has been previously disconnected and you want to restore the connection, use 
                    //     one of the asynchronous 'BeginConnect()' methods to reconnect. Use the 'Poll()' method to
                    //     determine when the Socket is finished connecting. 
                    // If, and only if, a string with server name (or IP address) and a Port number were supplied
                    //     as arguments, and there is IPv6 address associated to the server, these IPv6 address 
                    //     will be tryed first. If the server is not listen to IPv6 address, it will delay the
                    //     connection process.
                    // A few of the Exceptions bellow can be thrown only in a few overloads of "Connect()" method, NOT ALL overloads.
                } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                    // Use the 'SocketException.ErrorCode' property to obtain the specific error code. Refer to the
                    //     "Windows Sockets" version 2 API error code documentation in the MSDN library for a detailed
                    //     description of the error.
                    Console.WriteLine("SocketException while Connecting this client to a server. :: " + e.Message);
                } catch (ObjectDisposedException e) {  // Socket has been closed.
                    Console.WriteLine("ObjectDisposedException while Connecting this client to a server. :: " + e.Message);
                } catch (ArgumentOutOfRangeException e) { // The port number is not valid.
                    Console.WriteLine("ArgumentOutOfRangeException while Connecting this client to a server. :: " + e.Message);
                } catch (NotSupportedException e) {  // The "Connect()" method can be used only for sockets in the InterNetwork or InterNetworkV6 families.
                    Console.WriteLine("NotSupportedException while Connecting this client to a server. :: " + e.Message);
                } catch (ArgumentNullException e) {  // The addresses is null.
                    Console.WriteLine("ArgumentNullException while Connecting this client to a server. :: " + e.Message);
                } catch (ArgumentException e) {  // The length of address (string or array of IPAddress) is zero.
                    Console.WriteLine("ArgumentException while Connecting this client to a server. :: " + e.Message);
                } catch (InvalidOperationException e) {  // The Socket has been placed in a listening state by calling Listen(Int32).
                    Console.WriteLine("InvalidOperationException while Connecting this client to a server. :: " + e.Message);
                } catch (SecurityException e) { // A caller higher in the call stack does not have permission for the requested operation.
                    Console.WriteLine("SecurityException while Connecting this client to a server. :: " + e.Message);
                }
                if (ClientSocket.Connected) {
                    // The 'Connected' property indicates whether a Socket is connected to a remote host as of the LAST 
                    //     I/O operation (Send or Receive), i.e., reflects the state of the connection as of the most 
                    //     recent operation. To determine the current state of the connection, make a nonblocking, zero-byte
                    //     Send call. If the call returns successfully or throws a WAEWOULDBLOCK error code (10035),
                    //     then the socket is still connected; otherwise, the socket is no longer connected.
                    try {
                        Console.WriteLine("Connection established: \n\twith server IP {0}, Port {1};\n\tusing local IP {2}, Port {3}.",
                                      ((IPEndPoint)ClientSocket.RemoteEndPoint).Address.ToString(),
                                      ((IPEndPoint)ClientSocket.RemoteEndPoint).Port,
                                      ((IPEndPoint)ClientSocket.LocalEndPoint).Address.ToString(),
                                      ((IPEndPoint)ClientSocket.LocalEndPoint).Port);
                    } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                        Console.WriteLine("SocketException while reading LocalEndPoint or RemoteEndPoint property, after been connected. :: " + e.Message);
                    } catch (ObjectDisposedException e) {  // Socket has been closed.
                        Console.WriteLine("ObjectDisposedException while reading LocalEndPoint or RemoteEndPoint property, after been connected. :: " + e.Message);
                    }
                    ScktConnected = true;
                    break;
                    //} else {
                    //    Console.WriteLine("  ... No connection while trying server address:\n\tIP: {0}; Port: {1}.",
                    //                    ipep.Address.ToString(), ipep.Port);
                }
            }
            if (ScktConnected == false) {
                if (IPv4_priority == true) {
                    ++IP_Tests_phase;
                    if ((IP_Tests_phase == 1) && (Has_IPv6 == true)) {
                        goto CONNECTION_PROC;
                    } else {
                        Console.WriteLine("It was impossible to establish connection to server. Try it later.");
                        return false;
                    }
                }
                Console.WriteLine("It was NOT possible to establish connection to server. Try it later.");
                return false;
            } else {
                return true;
            }
            #endregion
        }


        public int ClientSEND(string msg, UTF8Encoding enc = null) {
            // To ensure that encoded bytes are decoded properly, you should use a Unicode encoding, such as 
            // UTF8Encoding or UnicodeEncoding. You could also use a higher-level protocol to ensure that the
            // same format is used for encoding and decoding.
            if (enc == null) { enc = new UTF8Encoding(); }  // If no Encoding is passed to parmeter 'enc', create the UTF8 enconding is applied.
            byte[] bytemsg = null;
            try {
                bytemsg = enc.GetBytes(msg);  // Encode the data string into a byte array.
            } catch (ArgumentNullException e) {
                Console.WriteLine("ArgumentNullException while this Client was enconding received data from Server. " + e.Message);
            } catch (DecoderFallbackException e) {
                Console.WriteLine("DecoderFallbackException while this Client was enconding received data from Server. " + e.Message);
            }
            return ClientSEND(bytemsg);

        }


        public int ClientSEND(byte[] payload, int amount = int.MinValue, int init_ix = int.MinValue) {
            // A initial negative value (int.MinValue) is used as a flag to indicate default values.
            if (init_ix < 0) { init_ix = 0; }  // Default value to init_ix is to send all 'payload' data, starting at index 0. 
            if (amount < 0) { amount = payload.Length; }  // Default value to amount is to send all 'payload' data. 

            int bytesSent = 0;  // Number of bytes sent in the last call of 'ClientSocket.Send()'.
            int totalSent = 0;  // Total number of bytes sent by a single call of this method ( 'ClientSEND()' ), independently of how many times the method 'ClientSocket.Send()' were call inside it.
            int countSendCall = 0;   // Number of times that method 'ClientSocket.Send()' were called inside single call of 'ClientSEND()'.
            int sendRetry = 0;  // Count the number of times that method 'ClientSocket.Send()' returned value zero inside a single call of 'ClientSEND()', to create a customized time-out.
            SocketError ClientSocketError = SocketError.Fault;

            Console.WriteLine("\t#About to start to send data:\n\t\tClientSocket.Blocking:= {0};\n\t\tAmount of data to send (amount):= {1};" +
                          "\n\t\tBuffer initial index position (init_ix):= {2}.", ClientSocket.Blocking, amount, init_ix); // Used only for tests puposes.


            try {
                while (totalSent < amount) { // this while loop is intended only for situations when 'Socket.Blocking' property is set to 'false'. 
                    bool retry;
                    do { // while ((bytesSent == 0) && (sendRetry < SendReTryLim)) {
                        // If server's socket receiver buffer is full and the Client calls 'socket.Send()' one more time after it,
                        // the amount of sent bytes will be '0'. To minimize this sort of problem, by providing a "secodn level" of
                        // time-out (beyond 'ClientSocket.SendTimeout' ) this 'while((bytesSent==0) && (sendRetry < SendReTryLim))' loop
                        // was implemented.

                        bytesSent = ClientSocket.Send(payload, init_ix + totalSent, amount - totalSent, SocketFlags.None, out ClientSocketError);
                        // Send the data through the socket and returns the number of bytes that were successfully sent.
                        // The size of data to be send must not exceed the maximum packet size of the underlying service provider, or the datagram will not be sent and a 'SocketException' will thrown. 
                        // In connection-oriented protocol (TCP), 'Send()' will block until the requested number of bytes are sent,
                        //     unless a time-out was set by using 'Socket.SendTimeout'. If the time-out value was exceeded,
                        //     the Send call will throw a SocketException. In nonblocking mode, 'Send()' may complete successfully
                        //     even if it sends less data than the number of bytes you request. It is your application's
                        //     responsibility to keep track of the number of bytes sent and to retry the operation until
                        //     the application sends the requested number of bytes.
                        // A successful completion of the 'Send()' method means that the underlying system has had room to buffer
                        //     your data for a network send. So, the successful completion of a send does not indicate that the
                        //     data was successfully delivered.
                        totalSent += bytesSent;

                        Console.WriteLine("\t***ClientSocket.Send() called by x {0} time.\n\t\tbytesSent:= {1};" +
                                              "\n\t\ttotalSent:= {2};\n\t\tClientSocketError:= {3}",
                                              ++countSendCall, bytesSent, totalSent, ClientSocketError.ToString()); // Used only for tests puposes.
                        retry = (bytesSent == 0) && (sendRetry < SendReTryLim);
                        if (retry) {
                            Thread.Sleep(SendReTryInterval);
                            ++sendRetry;
                        }
                    } while (retry);
                    if (bytesSent == 0) {   // ...and also (sendRetry >= SendReTryLim)
                        Console.WriteLine("\t%%% The Client has interrupted the Send() process because it exceeds the limit number of retries." +
                                          " Total bytes send: {0}", bytesSent);
                        break;
                    }
                    if (ClientSocketError == SocketError.Success) {
                        if (totalSent == amount) {
                            Console.WriteLine("\t***ALL data were SUCCESSFULLY sent from Client to Server.");
                        } else {  // This possiblility may happen if 'Socket.Blocking' property is set to 'false'. 
                            Console.WriteLine("\t***A SENT from Client to Server happened with success, but ONLY {0} bytes FROM a total of {1} had been sent.",
                                              totalSent, amount);
                            continue; // Give another chance to send all data.
                        }
                    } else {
                        if (totalSent != amount) {
                            Console.WriteLine("\t***A SENT from Client to Server happened with error '{0}', and {1} bytes FROM a total of {2} had been sent.",
                                              ClientSocketError.ToString(), bytesSent, amount);
                        } else {  // I (Vinicius) am not sure if this situation ( (ClientSocketError != SocketError.Success) && (bytesSent == payload.Length) may happen. 
                            Console.WriteLine("\t%%% Although all data were successfully sent from Client to Server, there was an error '{0}'.", ClientSocketError.ToString());
                        }
                        break;
                    }

                }
            } catch (SocketException e) {  // An error occurred when attempting to access the socket. The 'SocketFlags' argument is not a valid combination of values. 
                // Use the 'SocketException.ErrorCode' property to obtain the specific error code. Refer to the
                //     "Windows Sockets" version 2 API error code documentation in the MSDN library for a detailed
                //     description of the error.
                Console.WriteLine("SocketException while Sending data from client to server. :: " + e.Message + "\n\t\tSocketException.ErrorCode = " + e.ErrorCode);
            } catch (ObjectDisposedException e) {  // Socket has been closed.
                Console.WriteLine("ObjectDisposedException while Sending data from client to server. :: " + e.Message);
            } catch (ArgumentOutOfRangeException e) { // The value of the starting index or the amount of data to be send is not valid.
                Console.WriteLine("ArgumentOutOfRangeException while Sending data from client to server. :: " + e.Message);
            } catch (ArgumentNullException e) {  // The buffer (byte array) is null.
                Console.WriteLine("ArgumentNullException while Sending data from client to server. :: " + e.Message);
            } catch (ArgumentException e) {  // The buffer (byte array) is empty.
                Console.WriteLine("ArgumentException while Sending data from client to server. :: " + e.Message);
            }

            Console.WriteLine("\t###Final results from ClientSEND():\n\t\tClientSocket.Send() called by x {0} time.;" +
                          "\n\t\ttotalSent:= {1};\n\t\tClientSocketError:= {2}", countSendCall, totalSent, ClientSocketError.ToString());  // Used only for tests puposes.


            return totalSent;
        }


        public int ClientRECEIVE(out string msgtxt, int buffersize = 1500, UTF8Encoding enc = null) {
            // The default value for 'buffersize' is the Maximum Ethernet Payload Size, i.e. 1500 octets (plus a 30 octets header).

            // To ensure that encoded bytes are decoded properly, you should use a Unicode encoding, such as 
            // UTF8Encoding or UnicodeEncoding. You could also use a higher-level protocol to ensure that the
            // same format is used for encoding and decoding.
            if (enc == null) { enc = new UTF8Encoding(); }  // If no Encoding is passed to parmeter 'enc', create the UTF8 enconding is applied.
            byte[] bytemsg = new byte[buffersize];
            int bytesrec = ClientRECEIVE(bytemsg);
            msgtxt = null;
            try {
                msgtxt = enc.GetString(bytemsg);  // Encode the data string into a byte array.
            } catch (ArgumentNullException e) {
                Console.WriteLine("ArgumentNullException while this Client was enconding received data from Server. " + e.Message);
            } catch (DecoderFallbackException e) {
                Console.WriteLine("DecoderFallbackException while this Client was enconding received data from Server. " + e.Message);
            } catch (ArgumentException e) {
                Console.WriteLine("ArgumentException while this Client was enconding received data from Server. " + e.Message);
            }
            return msgtxt.Length;
        }


        public int ClientRECEIVE(byte[] msg, int amountMax = int.MinValue, int init_ix = int.MinValue) {
            // A initial negative value (int.MinValue) is used as a flag to indicate default values on optional parameters.
            if (init_ix == int.MinValue) { init_ix = 0; }  // Default value to init_ix is to fill all 'msg' elements  with received data, starting at index 0. 
            if (amountMax == int.MinValue) { amountMax = (msg?.Length ?? 0); }  // Default value to amountMax is to fill all 'msg' elements  with received data. 

            int bytesRead = -1;  // Number of bytes retrieved from (Network Interface Card) reception buffer in the last call of 'sock.Receive()'.
                                 // A initial negative value is used to start the "while ((totalReceiv < amountMax) && (bytesRead!=0)){}" loop.
            int totalReceiv = 0; // Total number of bytes retrieved from (Network Interface Card) reception buffer in a single call to 'ServerRECEIVE()' method, independently of the number of calls to 'sock.Receive()'.
                                 // In TCP protocol, when a data block is divided in many packets, the 'Receive()' 
                                 //     method may return only one part of sent data block, because not all packets has 
                                 //     been received by network interface card at the time 'Receive()' was called.
            SocketError sockError = SocketError.Fault;
            int remain = 0; // Amount of bytes that was not retrieved from the queue of socket. Must be a nullable integer because "remain = sock.Available;" can throw an Exception.
            int countReceivCall = 0; // Number of times that "sock.Receive()" was called.
            int receiveRetry = 0;   // Number of times that "sock.Receive()" returned zero value, allowing to implement a customized time-out.

            try {

                // If "Socket.Blocking" is 'true' (blocking mode) and no data is available for reading, the 
                //     'Receive()' method will block until data is available, unless a time-out value was set 
                //     by using 'Socket.ReceiveTimeout()'.  If time-out expires, 'Receive()' method will throw
                //     'SocketException'.
                // If "Socket.Blocking" is 'false' (non-blocking mode), and there is no data available in the in
                //     the protocol stack buffer, the 'Receive()' method will complete (its execution thread) 
                //     immediately and throw a 'SocketException'.

                Console.WriteLine("\t#About to start to reveice data:\n\t\tClientSockets.Blocking:= {0};\n\t\tBuffer size (amountMax):= {1};" +
                                  "\n\t\tBuffer initial index position (init_ix):= {2};\n\t\tAvailable data (remain):= {3}",
                                  ClientSocket.Blocking, amountMax, init_ix, remain.ToString()); // Used only for tests puposes.

                while (totalReceiv < amountMax)  { // ((totalReceiv < amountMax) && (bytesRead != 0)) { // this while loop is intended only for situations when 'Socket.Blocking' property is set to 'false'. 
                    bool retry;  // flag to avoid to check same condition twice, inside customized time-out algorithm;
                    do { // This loop gives a customized time-out of 'ReceiveReTryLim' (iterations) x 'ReceiveReTryInterval' (miliseconds of 'Sleep()') to wait for arraival of all 'amountMax' data bytes that this server hopes to receive.
                        try {
                            remain = ClientSocket.Available; // Return the amount of data that has been received from the 
                                 // (bound host, specified in 'Connect()' or by 'Accept()' methods) and still is
                                 // available to be read, i.e. was not retrieved from network card interface yet.
                                 // The access to 'Available' property may throw 'SocketException' or 'ObjectDisposeException'.
                        } catch (Exception e) {
                            Console.WriteLine("\t***Impossible to check received data (from Server) in this Client buffer queue." + e.Message);
                            remain = 0;
                        }
                        retry = (remain == 0) && (receiveRetry < ReceiveReTryLim);
                        if (retry) {
                            Thread.Sleep(ReceiveReTryInterval);
                            ++receiveRetry;
                        }
                    } while (retry);
                    if (remain == 0) {   // ... and also "(receiveRetry >= ReceiveReTryLim)"
                        Console.WriteLine("\t%%% Customized Receive Time-Out for this Client expired after {0} seconds of waiting.", ReceiveReTryLim * ReceiveReTryInterval / 1000);
                        break;
                    //} else {
                    //    // receiveRetry = 0;  // Reset 'receiveRetry' every time that arrive any data in reception buffer.
                    //    receiveRetry = ReceiveReTryLim;  // Deactivate customized time-out after call 'ClientSocket.Receive()'.
                    }
                    bytesRead = ClientSocket.Receive(msg, init_ix + totalReceiv, amountMax - totalReceiv, SocketFlags.None, out sockError);
                    // Receives data from a bound Socket and returns the amount of bytes received.
                    // The size of data to be send must not exceed the maximum packet size of the underlying service provider, or the datagram will not be sent and a 'SocketException' will thrown. 

                    // In connection-oriented protocol (TCP), 'Receive()' method will read all available data,
                    //     up to the number of bytes in size parameter. If the remote host (server) calls 
                    //     'Shutdown()' method (to shut down the connection), and all (old) available data has already 
                    //     been received, 'Receive()' method will complete (its execution thread) immediately and
                    //     return zero bytes.
                    // In a connectionless protocol (UDP), 'Receive()' method will read the first queued 
                    //     datagram from the destination address specified in 'Connect()' method. If received
                    //     datagram is larger than buffer parameter size, buffer is filled with the first part
                    //     of the datagram message, the excess data is lost and a 'SocketException' is thrown. 

                    totalReceiv += bytesRead;

                    Console.WriteLine("\t#ClientSocket[x].Receive() called by x {0} time." +
                                  "\n\t\tbytesRead:= {1};\n\t\ttotalReceiv:= {2};\n\t\tremain:= {3}" +
                                  "\n\t\tSocketError:= {4}",
                                  ++countReceivCall, bytesRead, totalReceiv, remain.ToString(), sockError.ToString()); // Used only for tests puposes.

                    if (sockError == SocketError.Success) {
                        if (totalReceiv == amountMax) {
                            Console.WriteLine("\t***This Client retrieved SUCCESSFULLY ALL requested data from Client.");  // ("\nThis Server received ALL required data from Client, SUCCESSFULLY.");
                            if (remain > 0)
                                Console.WriteLine("\t***There is more available data (from the server) to be retrieved by this Client: {0} bytes.", remain); 
                        } else {  // This possiblility may happen if 'Socket.Blocking' property is set to 'false' or time-out expire or data block sent is greater than receiver device buffer. 
                            Console.WriteLine("\t***This Client received PART of requested data from Server: {0} bytes FROM a total requested of {1}.",
                                              totalReceiv, amountMax);
                        }
                    } else {
                        if (totalReceiv != amountMax) {
                            Console.WriteLine("\n\t***This Client received PART of requested data from Server with error '{0}'; {1} bytes FROM a total requested of {2}.",
                                              sockError.ToString(), totalReceiv, amountMax);
                        } else {  // I (Vinicius) am not sure if this situation ( (ClientSocketError != SocketError.Success) && (bytesSent == payload.Length) may happen. 
                            Console.WriteLine("\n\t%%% Although this Client read all requested data from Server, there was an error '{0}'.", sockError.ToString());
                        }
                        break;
                    }
                }
            } catch (SocketException e) {  // An error occurred when attempting to access the socket. The time while 'Socket.Receive()' blocks (program execution) waiting for data arraival exceeded 'Socket.ReceiveTimeout' property. The 'socketFlags' argument is not a valid combination of values. The 'LocalEndPoint' property is not set. 
                // Use the 'SocketException.ErrorCode' property to obtain the specific error code. Refer to the
                //     "Windows Sockets" version 2 API error code documentation in the MSDN library for a detailed
                //     description of the error.
                Console.WriteLine("SocketException while this Client was Receiving data from Server. :: " + e.Message + "\n\t\tSocketException.ErrorCode = " + e.ErrorCode);
            } catch (ObjectDisposedException e) {  // Socket has been closed.
                Console.WriteLine("ObjectDisposedException while this Client was Receiving data from Server. :: " + e.Message);
            } catch (ArgumentOutOfRangeException e) { // The value of the starting index or the amount of data to be received is not valid.
                Console.WriteLine("ArgumentOutOfRangeException while this Client was Receiving data from Server. :: " + e.Message);
            } catch (ArgumentNullException e) {  // The buffer (byte array) is null.
                Console.WriteLine("ArgumentNullException while this Client was Receiving data from Server. :: " + e.Message);
            } catch (SecurityException e) { // A caller higher in the call stack does not have permission for the requested operation.
                Console.WriteLine("SecurityException while Connecting this Client to the Server. ::  :: " + e.Message);
            }

            try {
                remain = ClientSocket.Available; // May throw 'SocketException' or 'ObjectDisposeException'.
            } catch (Exception) {
                Console.WriteLine("\n\t%%% It was not possible to determine if STILL there is some data (from the server) to be retrieved to this Clien.");
                remain = -1;
            }
            Console.WriteLine("\t### Final results from ClientRECEIVE():\n\t\tClientSocket[x].Receive() called by x {0} time." +
                          "\n\t\ttotalReceiv:= {1};\n\t\tremain:= {2};\n\t\tSocketError:= {3}",
                          countReceivCall, totalReceiv, remain, sockError.ToString()); // Used only for tests puposes.

            return totalReceiv;

        }


        public bool ClientSENDFILE(string Filename, byte[] prebuf = null, byte[] postbuf = null) {
            if ((Filename == null) || (Filename == string.Empty) || (Filename.Trim() == string.Empty)) {
                return false;
            }

            char sep = '%'; // Used to separate distinct information substrings about fully qualified name of file 'Filename' inside a single string 'FlInfDescrip'.
            string FlInfDescrip = null;
            FileInfo FlInf = null;

            #region "Get_File_info"
            if (prebuf == null) {
                try {
                    FlInf = new FileInfo(Filename);
                    FlInfDescrip = FlInf.Length + sep +
                                      FlInf.FullName + sep +
                                      FlInf.Extension + sep +
                                      FlInf.Attributes.ToString() + sep +
                                      FlInf.LastWriteTime.ToString() + sep +
                                      FlInf.LastWriteTimeUtc.ToString() + sep +
                                      FlInf.DirectoryName;
                    prebuf = Encoding.UTF8.GetBytes(FlInfDescrip);
                } catch (ArgumentNullException e) { //fileName is null.
                    Console.WriteLine("ArgumentNullException while reading metada about file (" + Filename + "):  :: " + e.Message);
                } catch (SecurityException e) { //The caller does not have the required permission.
                    Console.WriteLine("SecurityException while reading metada about file (" + Filename + "):  :: " + e.Message);
                } catch (ArgumentException e) { //The file name is empty, contains only white spaces, or contains invalid characters.
                    Console.WriteLine("ArgumentException while reading metada about file (" + Filename + "):  :: " + e.Message);
                } catch (UnauthorizedAccessException e) { //Access to fileName is denied.
                    Console.WriteLine("UnauthorizedAccessException while reading metada about file (" + Filename + "):  :: " + e.Message);
                } catch (PathTooLongException e) { //The specified path, file name, or both exceed the system - defined maximum length.
                    Console.WriteLine("PathTooLongException while reading metada about file (" + Filename + "):  :: " + e.Message);
                } catch (NotSupportedException e) { //fileName contains a colon(:) in the middle of the string.
                    Console.WriteLine("NotSupportedException while reading metada about file (" + Filename + "):  :: " + e.Message);
                }
            }
            #endregion

            #region "Get_File_data"
            byte[] filedata = null;
            if (File.Exists(Filename)) {
                try {
                    FileStream fs = File.OpenRead(Filename);
                    filedata = new byte[FlInf.Length];
                    if (fs.Read(filedata, 0, filedata.Length) != FlInf.Length) {
                        Console.WriteLine("Error while reading file (" + Filename + ") data. Total read data is different from reported by 'FileInfo' class.");
                        return false;
                    }
                    // Console.WriteLine( (new UTF8Encoding()).GetString(filedata) );
                } catch (ArgumentOutOfRangeException e) { // The value of parameters 'offset' or 'count' is negative.
                    Console.WriteLine("ArgumentOutOfRangeException while reading file (" + Filename + ") data:  :: " + e.Message);
                } catch (ArgumentNullException e) { //fileName is null.
                    Console.WriteLine("ArgumentNullException while openning/reading file (" + Filename + "):  :: " + e.Message);
                } catch (SecurityException e) { //The caller does not have the required permission.
                    Console.WriteLine("SecurityException while openning/reading file (" + Filename + "):  :: " + e.Message);
                } catch (ArgumentException e) { //The file name is empty, contains only white spaces, or contains invalid characters.
                    Console.WriteLine("ArgumentException while openning/reading file (" + Filename + "):  :: " + e.Message);
                } catch (UnauthorizedAccessException e) { //Access to fileName is denied.
                    Console.WriteLine("UnauthorizedAccessException while openning/reading file (" + Filename + "):  :: " + e.Message);
                } catch (PathTooLongException e) { //The specified path, file name, or both exceed the system - defined maximum length.
                    Console.WriteLine("PathTooLongException while openning/reading file (" + Filename + "):  :: " + e.Message);
                } catch (DirectoryNotFoundException e) { //fileName contains a colon(:) in the middle of the string.
                    Console.WriteLine("DirectoryNotFoundException while openning/reading file (" + Filename + "):  :: " + e.Message);
                } catch (FileNotFoundException e) { // fileName contains a colon(:) in the middle of the string.
                    Console.WriteLine("FileNotFoundException while openning/reading file (" + Filename + "):  :: " + e.Message);
                } catch (NotSupportedException e) { // The stream does not support reading.
                    Console.WriteLine("NotSupportedException while reading file (" + Filename + ") data:  :: " + e.Message);
                } catch (IOException e) { // An I/O error occurred.
                    Console.WriteLine("IOException while reading file (" + Filename + ") data:  :: " + e.Message);
                } catch (ObjectDisposedException e) { // Methods were called after the stream was closed.
                    Console.WriteLine("ObjectDisposedException while reading file (" + Filename + ") data:  :: " + e.Message);
                }
            }
            #endregion


            /*
                        try {
                                ClientSocket.SendFile(Filename, prebuf, postbuf, TransmitFileOptions.UseDefaultWorkerThread);
                            // Sends the file fileName and buffers of data to a connected Socket object using 'TransmitFile()' function.
                            //*** 'TransmitFile()' function is a Microsoft-specific extension to the Windows Sockets specification.***

                            // The 'Sendfile()' method synchronously sends a file only to remote host specified in 
                            //     'Connect()' or 'Accept()' methods.
                            // In a connection-oriented protocol (TCP) , with 'Socket.Bloking' equals to 'true', 'SendFile()' 
                            //     blocks until the entire file is sent. With 'Socket.Bloking' equals to 'false', 
                            //     'SendFile()' may complete (return from its execution) successfully before the entire file
                            //     has been sent.
                            // There is no guarantee that file data will appear on network immediately. A successful
                            //     completion of 'SendFile()'  means ONLY that the underlying system has had room to 
                            //     buffer the data for a network send.
                        } catch (NotSupportedException e) {  //The socket is not connected to a remote host.
                            Console.WriteLine("NotSupportedException while Client was sending a file to the server. :: " + e.Message);
                        } catch (ObjectDisposedException e) {  //The Socket object has been closed.
                            Console.WriteLine("ObjectDisposedException while Client was sending a file to the server. :: " + e.Message);
                        } catch (InvalidOperationException e) {  //The Socket object is not in blocking mode and cannot accept this synchronous call.
                            Console.WriteLine("InvalidOperationException while Client was sending a file to the server. :: " + e.Message);
                        } catch (FileNotFoundException e) {  // The file fileName was not found.
                            Console.WriteLine("FileNotFoundException while Client was sending a file to the server. :: " + e.Message);
                        } catch (SocketException e) {  //An error occurred when attempting to access the socket.
                            Console.WriteLine("SocketException while Client was sending a file to the server. :: " + e.Message);
                        }
            */

            int byteSent;
            if (prebuf != null) {
                byteSent = ClientSEND(prebuf);
                if (byteSent != prebuf.Length) { return false; }
            }
            if (filedata != null) {
                byteSent = ClientSEND(filedata);
                if (byteSent != filedata.Length) { return false; }
            }
            if (postbuf != null) {
                byteSent = ClientSEND(postbuf);
                if (byteSent != postbuf.Length) { return false; }
            }
            return true;
        }


        public void ClientReleaseComm() {
            // Release the Socket
            try {
                ClientSocket.Shutdown(SocketShutdown.Both);
                // In a connection-oriented protocol (TCP), always call the 'Shutdown()' method before closing the
                //     Socket to ensure that all data is sent and received on the connected socket before it is closed.
                //     Using 'Shutdown()' on a connectionless protocol is not recommended.
            } catch (SocketException e) { // An error occurred when attempting to access the socket.
                Console.WriteLine("SocketException while Shuting Down Client socket:  :: " + e.Message);
            } catch (ObjectDisposedException e) { // The Socket has been closed.
                Console.WriteLine("ObjectDisposedException while Shuting Down Client socket:  :: " + e.Message);
            }

            // There is two options to close the socket: 'Close()' either 'Disconnect()'.
            //     'Close()' will NOT allow reuse of socket and will NOT throw Exceptions;
            //     'Disconnect()' allows REUSE of socket, but may throw Exceptions.

            /*     try {
                       ClientSocket.Disconnect(true);
                       // A connection-oriented protocol, you can use this method to close the socket. This method ends
                       //     the connection and sets the Connected property to false. However, if method's argument  
                       //     is 'true', the socket can be reused.
                       if (ClientSocket.Connected) { Console.WriteLine("We're still connnected");
                       } else { Console.WriteLine("We're disconnected"); }
                    } catch (PlatformNotSupportedException e) {  // This method requires Windows 2000 or earlier, or the exception will be thrown.
                       Console.WriteLine("PlatformNotSupportedException while Disconnecting the client socket:  :: " + e.Message)
                    } catch (SocketException e) { // An error occurred when attempting to access the socket.
                        Console.WriteLine("SocketException while Shuting Down Client socket:  :: " + e.Message);
                    } catch (ObjectDisposedException e) { // The Socket has been closed.
                        Console.WriteLine("ObjectDisposedException while Shuting Down Client socket:  :: " + e.Message);
                   }  
            */
            ClientSocket.Close(10);
            // Closes the Socket connection and releases all associated resources with a specified timeout to allow
            //     queued data to be sent.
            // If it needs to call 'Close(time-out)' without first calling 'Shutdown()', it is possible to ensure that data
            //     queued for outgoing transmission will be sent by setting the 'DontLinger' option to 'false' and
            //     specifying a non-zero time-out interval. The 'Close(time-out)' will then block until this data is sent
            //     or until the specified time-out expires.  Time-out argument is in seconds. If you set 'DontLinger' to 
            //     'false' and specify a zero time-out interval, 'Close(0)' releases the connection and 
            //     automatically discards outgoing queued data.



            /* No MS Docs example calls 'ClientSocket.Dispose()'. It releases the unmanaged resources used by the Socket, 
            //     and optionally disposes of the managed resources. If argument is 'true' this method releases both 
            //     managed and unmanaged resources; if it is 'false' the method releases only unmanaged resources.
            // After calling 'Dispose()', you must release all references to the Socket so the garbage collector 
            //     can reclaim the memory area occuped by the Socket.
            */

        }


    }


    class TCP_Server_Sync {
        private string LocalSrvName = null; // Could be the name of this server on Internet, like: www.google.com.br, www.microsoft.com.br
        private IPAddress[] SrvIpAd = null;   // Array of IP addresses in which the SERVICE provided by this SERVER can be accessed by any Client.
        private ushort ServicePort = 4321; // Server will be listen this port. I. e., waiting for clients requesting for connection at this port.
        private int ClientPendingCon_max = 10; // Defines maximum amount of pending connections that will be queued by this server. Above this value, any client request for connection will be discarded.

        public Socket ServiceListeningSocket; //This is the Server socket that will LISTEN to any incoming connections. I. e., that wiil be waiting for clients requesting for connection at this port.
        public Socket[] ServiceClientSockets; // This is the array to save the complete sockets in the server.
        private int clientIndex = 0;  // Index of the next element in 'ServiceClientSockets' array to receive another accepted connection.
        private IPEndPoint ipep;  // The combination of network address and service port is defined by EndPoint class. For 'AddressFamily.InterNetwork'

        private bool IPv4_exclusive = true; // Try to connect using server IPv4 addresses before try IPv6 ones.

        private int SendReTryLim = 5;  // Number of times that Socket will try to send a message in a single call to 'ClientSEND()' method.
        private int SendReTryInterval = 2000;  // Number of miliseconds between each "send try" in a single call to 'ClientSEND()' method.
        private int ReceiveReTryLim = 3;  // Number of times that Socket will try to receive a message in a single call to 'ClientSEND()' method.
        private int ReceiveReTryInterval = 2000;  // Number of miliseconds between each "receive try" in a single call to 'ClientSEND()' method.


        public TCP_Server_Sync() {
            #region "User_sets_up_localserver_address_&_local_service_port"
            Console.WriteLine("\nEnter the SERVER's name (if it is logged on your DNS server) or IP address which you want to LISTEN to client requests:");
            try {
                LocalSrvName = Console.ReadLine();
                SrvIpAd = DNS_Resolver.Call_DNS_Resolver(LocalSrvName); // Only addresses associated with 
                          // 'LocalSrvName' in the DNS server will be returned. Others available address in this server
                          // that are not associated with 'LocalSrvName' in DNS Server will not be returned.
            } catch (Exception) {
                SrvIpAd = new IPAddress[] { IPAddress.Parse("127.0.0.1") };
            }

            Console.WriteLine("\nEnter the PORT number of the SERVICE you want to provide in this server:");

            string aux = null;
            try {
                aux = Console.ReadLine();
                if ((aux != null) && (aux.Trim() != string.Empty)) { // If user do not enter a valid string, let 'ServicePort' with default value. 
                    if (!ushort.TryParse(aux, out ServicePort))
                        ServicePort = 54321;
                }
            } catch (Exception) {
                ServicePort = 23451;
            }
            #endregion

            if ( ServerListen(1)) { // Server will set its IP address and a Port number and start to wait/listenning for client connection requests.
                ServiceClientSockets = new Socket[ClientPendingCon_max];

                ServiceClientSockets[clientIndex] = ServerAccept();  // Server establishes connection to request client from server's network card interface queue.
                if (ServiceClientSockets[clientIndex] != null) {
                    int ix = clientIndex;
                    ++clientIndex;

                    //Console.WriteLine("Press any key to receive data from Client.");
                    //Console.Read(); // Console.WriteLine("Int code from key pressed: {0}", Console.Read());

                    byte[] msg1 = new byte[1024 * TCPinfo.Tcp_pl_maxTU]; // Maximum TCP Payload Size is 64k octets (plus its header).
                    int bytesReceiv = ServerRECEIVE(ServiceClientSockets[ix], msg1, msg1.Length);
                    if (bytesReceiv == msg1.Length) {
                        Console.WriteLine("SERVER Received successfully, all {0} bytes were read in a single call to 'ServerRECEIVE()'.", bytesReceiv);
                    } else {
                        Console.WriteLine("SERVER Received partialy successfull, only {0} bytes were read in a single call to 'ServerRECEIVE()'.", bytesReceiv);
                    }

                    //byte[] msgB = new byte[TCPinfo.Eth_pl_minTU];
                    //bytesReceiv = ServerRECEIVE(ServiceClientSockets[ix], msgB, msgB.Length);
                    //if (bytesReceiv == msgB.Length) {
                    //    Console.WriteLine("SERVER Receive success, all {0} data bytes were read with a single call to 'ServerRECEIVE()'.", bytesReceiv);
                    //} else {
                    //    Console.WriteLine("SERVER Receive partial success, only {0} data bytes were read with a single call to 'ServerRECEIVE()'.", bytesReceiv);
                    //}

                    if (ServerSEND(ServiceClientSockets[ix], msg1, bytesReceiv) == bytesReceiv) {
                        Console.WriteLine("SERVER Sent successfully, all {0}  bytes were sent with a single call to 'ServerSEND()'.", bytesReceiv);
                    } else {
                        Console.WriteLine("SERVER Sent partialy successfull, only {0} bytes were sent in a single call to 'ServerSEND()'.", bytesReceiv);
                    }

                    // Release the ServiceClientSocket
                    Console.WriteLine("Press ENTER key to Shutdown Connection of this server with client " + ipep.Address.ToString());
                    Console.Read();
                    ServerReleaseClientComm(ServiceClientSockets[ix]);
                    --clientIndex;

                }

            }

            // Release the ServiceListeningSocket
            ServerReleaseListening();


        }


        public bool ServerListen(int conn = int.MinValue) {
            #region "CREATE_LISTENER_SOCKET"
            if ((SrvIpAd?.Length ?? 0) > 0) {
                try {
                    ServiceListeningSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                    //  A Socket must be initialized with Transport and Network Protocols information (".NET" uses three Enums for this AddressFamily, SocketType and ProtocolType).
                    // AddressFamily Enum has fields: InterNetwork (for IP v4), InterNetworkV6 (for IP v6), AppleTalk, Ccitt (for X.25), Ipx, Unix, Unknown, etc.
                    // SocketType Enum defines properties of used Protocols (connection-oriented, message-oriented, connectionless, duplicated/out of order packets arrive).
                    // SocketType Enum has fields: Raw (to acces underlying transport protocol (providing a complete IP header) or protocols: ICMP, IGMP), 
                    //        Dgram (for UDP), Stream (for TCP), Unknown, etc. 
                    // ProtocolType Enum has fields: IPv4, IPv6, Raw, Ipx, Tcp, Udp, Unknown, etc.
                    // Trying to create a Socket with an incompatible combination (of SockteTypee and ProtocolType) throws a SocketException.
                    // https://docs.microsoft.com/en-us/dotnet/api/system.net.sockets.socket?view=netframework-4.7.2
                } catch (SocketException e) {  // Combination of addressFamily, socketType, and protocolType results in an invalid socket.
                    Console.WriteLine("Failure while defining Communications Protocols. :: " + e.Message);
                    Console.WriteLine("Connection cannot be initialized without a Protocol.");
                    return false;
                }
            } else {
                Console.WriteLine("Connection cannot be initialized without BIND and End Point (host address) to this server.");
                return false;
            }

            try {
                // ServiceListeningSocket.ReceiveTimeout = 500; // The time-out value to synchronous 'Socket.Receive()' call, in milliseconds. The default value is 0, which indicates an infinite time-out period.
                //    In Linux (4.15.0-38-generic #41~16.04.1-Ubuntu) with Mono (MonoDevelop: 7.6.9 (build 22); Runtime: Mono 5.16.0.179 e GTK+ 2.24.30 ),
                //    setting 'ServiceListeningSocket.ReceiveTimeout' property will turn this socket to non-blocking mode and it will throw an SocketException in method 'Accept()'.
                // ServiceListeningSocket.SendTimeout = 500; // The time-out value to synchronous 'Socket.Send()' call, in milliseconds. The default value is 0, which indicates an infinite time-out period. Value between 1 and 499 will be changed to 500.
                // ServiceListeningSocket.Blocking = true; // If you want execution to continue (without blocking current thread) even though the requested operation ('Connect', 'Send', 'Receive') is not complete, change the Blocking property to false. The 'Socket.Blocking' property should be set to true for TCP protocol to avoid Exceptions.
                // ServiceListeningSocket.DualMode = true;  // The Socket is a dual-mode socket used for both IPv4 and IPv6. No Exception is thrown.
                //    In Linux (4.15.0-38-generic #41~16.04.1-Ubuntu) with Mono (MonoDevelop: 7.6.9 (build 22); Runtime: Mono 5.16.0.179 e GTK+ 2.24.30 ),
                //    setting 'ServiceListeningSocket.DualMode' property will throw an SocketException here'.
                // ServiceListeningSocket.Ttl = 42;  // Set the Time To Live (TTL) to 42 router hops.
                // ServiceListeningSocket.ExclusiveAddressUse = true; // Set to 'true' if the Socket allows only one socket to bind to a specific port;
                // ServiceListeningSocket.NoDelay = false;   // Set 'false' if the Socket uses the Nagle algorithm. The Nagle algorithm is designed to reduce network traffic by causing the socket to buffer small packets and then combine and send them in one packet under certain circumstances. Setting this property on a User Datagram Protocol (UDP) socket will have no effect.
                // ServiceListeningSocket.SendBufferSize = 8192;  // Larger buffer might delay the recognition of connection difficulties. Consider increasing the buffer size if you are transferring large files, or you are using a high bandwidth, high latency connection (such as a satellite broadband provider.)
                // ServiceListeningSocket.ReceiveBufferSize = 8192; // Larger buffer potentially reduces the number of empty acknowledgements (TCP packets with no data portion), but might also delay the recognition of connection difficulties.
                // try {
                //     ServiceListeningSocket.LingerState = new LingerOption(true, 3); // For connection-oriented protocol (TCP). It specify a custon amount of time (in seconds) that the Socket will attempt to transmit remaining unsent data after 'Close()' or 'Disconnect()' methods has been called.
                //     // If 'LingerOption' is set to 'false' Socket will try to send remaining unsent data until default IP protocol time-out expires.
                //     // When the LingerTime property stored in the LingerState property is set greater than the default IP protocol time-out, the default IP protocol time-out will still apply and override.
                // } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                //     Console.WriteLine("SocketException while defining LingerState property. :: " + e.Message);
                // } catch (ObjectDisposedException e) {  // Socket has been closed.
                //     Console.WriteLine("ObjectDisposedException while defining LingerState property. :: " + e.Message);
                // }

                Console.WriteLine("\tLISTENNING socket:\n\t\tReceiveTimeout: {0};\tSendTimeout: {1};\n\t\tBlocking: {2};\tDualMode: {3};" +
                              "\n\t\tReceiveBufferSize: {4};\tSendBufferSize: {5};\n\t\tTtl: {6};\tNoDelay: {7};" +
                              "\n\t\tExclusiveAddressUse: {8}", ServiceListeningSocket.ReceiveTimeout, ServiceListeningSocket.SendTimeout,
                              ServiceListeningSocket.Blocking, "? ServiceListeningSocket.DualMode ?", ServiceListeningSocket.ReceiveBufferSize,
                              ServiceListeningSocket.SendBufferSize, ServiceListeningSocket.Ttl, ServiceListeningSocket.NoDelay,
                              ServiceListeningSocket.ExclusiveAddressUse);

            } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                Console.WriteLine("SocketException while defining Socket properties. :: " + e.Message);
            } catch (ObjectDisposedException e) {  // Socket has been closed.
                Console.WriteLine("ObjectDisposedException while defining Socket properties. :: " + e.Message);
            } catch (ArgumentOutOfRangeException e) { // The property value is invalid.
                Console.WriteLine("ArgumentOutOfRangeException while defining Socket properties. :: " + e.Message);
            } catch (InvalidOperationException e) {  // Bind(EndPoint) has been called for this Socket.
                Console.WriteLine("InvalidOperationException while defining Socket properties. :: " + e.Message);
            } catch (NotSupportedException e) {  // The "Ttl" property can be set only for sockets in the InterNetwork or InterNetworkV6 families
                Console.WriteLine("NotSupportedException while defining Socket properties. :: " + e.Message);
            }
            #endregion

            #region "BIND_N_LISTEN"
            foreach (IPAddress address in SrvIpAd) {
                if ((IPv4_exclusive == true) && (address.AddressFamily != AddressFamily.InterNetwork)) {
                    continue;
                }

                Console.WriteLine("Checking Server Listenning IP address: {0}; Port: {1}", address.ToString(), ServicePort);
                ipep = new IPEndPoint(address, ServicePort);
                try {
                    ServiceListeningSocket.Bind(ipep);
                    // The 'Bind()' method defines which address and port will be used by the server to wait for 
                    //     clients connection requests.
                    // For servers 'Bind()' method must always be called before 'Listen()' method. 
                    // If it is not important which local address is assigned/binded to the SERVICE provided by 
                    //     this server, create an IPEndPoint using 'IPAddress.Any' (0.0.0.0) as the address 
                    //     parameter, to bind the SERVICE on ALL network interface address.
                    //     To include all IPv6 and IPv4, use: "var listener = new TcpListener(IPAddress.IPv6Any, port); listener.Server.SetSocketOption(SocketOptionLevel.IPv6, SocketOptionName.IPv6Only, false);"
                    // If server will not listen on all its address, but NEED listen on MORE THAN ONE specific 
                    //     IPEndPoint to answer client requests, a new 'ServiceListeningSocket' must be created 
                    //     to each IPEndPoint before call 'Bind()' (to each IPEndPoint created).
                    // If it is not important which local PORT is used, create an 'IPEndPoint' using 0 for port
                    //     number, so system will assign an available port number between 1024 and 5000.
                    // If a UDP socket wants to receive interface information on received packets, the 'SetSocketOption()'
                    //     method should be explicitly called with the socket option set to 'PacketInformation' 
                    //     immediately after calling the 'Bind()' method. 
                    // To receive multicast datagrams, call 'Bind()' method with a multicast port number.
                    // Call 'Bind()' method to receive connectionless (UDP) datagrams using 'ReceiveFrom()' method.

                } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                    // Use the 'SocketException.ErrorCode' property to obtain the specific error code. Refer to the
                    //     "Windows Sockets" version 2 API error code documentation in the MSDN library for a detailed
                    //     description of the error.
                    Console.WriteLine("SocketException while BINDING address and port used by this server to listen to requestes. :: " + e.Message);
                } catch (ObjectDisposedException e) {  // Socket has been closed.
                    Console.WriteLine("ObjectDisposedException while BINDING address and port used by this server to listen to requestes. :: " + e.Message);
                } catch (ArgumentNullException e) {  // The IPEndPoint is null.
                    Console.WriteLine("ArgumentNullException while BINDING address and port used by this server to listen to requestes. :: " + e.Message);
                } catch (SecurityException e) { // A caller higher in the call stack does not have permission for the requested operation.
                    Console.WriteLine("SecurityException while BINDING address and port used by this server to listen to requestes. :: " + e.Message);
                }
                if (ServiceListeningSocket.IsBound == true) { break; } // For Blocking mode, even if it is desired to  Socket it does not worth create a "ServiceListeningSocket()" to each IPAddress

            }
            if (ServiceListeningSocket.IsBound != true) {
                Console.WriteLine("Error: the service socket seems to be NOT bound.");
                return false;
            }

            try {
                ServiceListeningSocket.Listen((conn == int.MinValue)? ClientPendingCon_max : conn);
                // The 'Listen()' method does NOT blocks (it return from execution immediatly). 
                // The 'Listen()' causes a connection-oriented protocol (TCP) to listen for client connection
                //    requests. 
                // The 'Bind()' method must be called before calling 'Listen()'.

                Console.WriteLine("Now, this Server is LISTEN to client's connection requests...");
                return true;
            } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                Console.WriteLine("SocketException while make this server to LISTEN to client connection requestes. :: " + e.Message);
            } catch (ObjectDisposedException e) {  // Socket has been closed.
                Console.WriteLine("ObjectDisposedException while make this server to LISTEN to client connection requestes. :: " + e.Message);
            }
            return false;
            #endregion

        }


        public Socket ServerAccept() {

            Socket s = null;
            try {
                s = ServiceListeningSocket.Accept();
                // The 'Accept()' method synchronously extracts first pending connection request from queue
                //     of the listening socket, and then creates and returns a new Socket. This new socket
                //     cannot be usesed to  accept any additional connections from queue.
                // In blocking mode, 'Accept()' blocks until an incoming connection attempt is queued. Once it is accepted,
                //     the original Socket continues queuing incoming connection requests until you close it.
                // A call to this method using a non-blocking Socket will throws a 'SocketException' if there is NO
                //     connection requests queued.
                // The 'Listen()' method must be called before calling the 'Accept()'.

                Console.WriteLine("\t#Connection request ACCEPTED:\n\t\tThis Server is using IP:{0}, Port:{1}\n\t\tremote client is using IP:{2}, Port:{3}",
                                   ((IPEndPoint)s.LocalEndPoint).Address.ToString(),
                                   ((IPEndPoint)s.LocalEndPoint).Port.ToString(),
                                   ((IPEndPoint)s.RemoteEndPoint).Address.ToString(),
                                   ((IPEndPoint)s.RemoteEndPoint).Port.ToString());

                try {
                    s.ReceiveTimeout = 500; // The time-out value to synchronous 'Socket.Receive()' call, in milliseconds. The default value is 0, which indicates an infinite time-out period.
                    s.SendTimeout = 500; // The time-out value to synchronous 'Socket.Send()' call, in milliseconds. The default value is 0, which indicates an infinite time-out period. Value between 1 and 499 will be changed to 500.
                    s.Blocking = true; // If you want execution to continue (without blocking current thread) even though the requested operation ('Connect', 'Send', 'Receive') is not complete, change the Blocking property to false. The 'Socket.Blocking' property should be set to true for TCP protocol to avoid Exceptions.
                    // s.DualMode = true;  // The Socket is a dual-mode socket used for both IPv4 and IPv6. No Exception is thrown.
                    //    In Linux (4.15.0-38-generic #41~16.04.1-Ubuntu) with Mono (MonoDevelop: 7.6.9 (build 22); Runtime: Mono 5.16.0.179 e GTK+ 2.24.30 ),
                    //    setting 'ServiceListeningSocket.DualMode' property will throw an SocketException here'.
                    // s.Ttl = 42;  // Set the Time To Live (TTL) to 42 router hops.
                    // s.ExclusiveAddressUse = true; // Set to 'true' if the Socket allows only one socket to bind to a specific port;
                    // s.NoDelay = false;   // Set 'false' if the Socket uses the Nagle algorithm. The Nagle algorithm is designed to reduce network traffic by causing the socket to buffer small packets and then combine and send them in one packet under certain circumstances. Setting this property on a User Datagram Protocol (UDP) socket will have no effect.
                    // s.SendBufferSize = 8192;  // Larger buffer might delay the recognition of connection difficulties. Consider increasing the buffer size if you are transferring large files, or you are using a high bandwidth, high latency connection (such as a satellite broadband provider.)
                    // s.ReceiveBufferSize = 8192; // Larger buffer potentially reduces the number of empty acknowledgements (TCP packets with no data portion), but might also delay the recognition of connection difficulties.
                    // try {
                    //     s.LingerState = new LingerOption(true, 3); // For connection-oriented protocol (TCP). It specify a custon amount of time (in seconds) that the Socket will attempt to transmit remaining unsent data after 'Close()" method has been called.
                    //     // If 'LingerOption' is set to 'false' Socket will try to send remaining unsent data until default IP protocol time-out expires.
                    //     // When the LingerTime property stored in the LingerState property is set greater than the default IP protocol time-out, the default IP protocol time-out will still apply and override.
                    // } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                    //     Console.WriteLine("SocketException while defining LingerState property. :: " + e.Message);
                    // } catch (ObjectDisposedException e) {  // Socket has been closed.
                    //     Console.WriteLine("ObjectDisposedException while defining LingerState property. :: " + e.Message);
                    // }

                    Console.WriteLine("\tACCEPTED (ServiceClient) socket:\n\t\tReceiveTimeout: {0};\tSendTimeout: {1};\n\t\tBlocking: {2};" +
                                  "\tDualMode: {3};\n\t\tReceiveBufferSize: {4};\tSendBufferSize: {5};\n\t\tTtl: {6};\tNoDelay: {7};" +
                                  "\n\t\tExclusiveAddressUse: {8}", s.ReceiveTimeout, s.SendTimeout, s.Blocking, 
                                  "?s.DualMode?", s.ReceiveBufferSize, s.SendBufferSize, s.Ttl, s.NoDelay, s.ExclusiveAddressUse);

                } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                    Console.WriteLine("SocketException while defining Socket properties. :: " + e.Message);
                } catch (ObjectDisposedException e) {  // Socket has been closed.
                    Console.WriteLine("ObjectDisposedException while defining Socket properties. :: " + e.Message);
                } catch (ArgumentOutOfRangeException e) { // The property value is invalid.
                    Console.WriteLine("ArgumentOutOfRangeException while defining Socket properties. :: " + e.Message);
                } catch (InvalidOperationException e) {  // Bind(EndPoint) has been called for this Socket.
                    Console.WriteLine("InvalidOperationException while defining Socket properties. :: " + e.Message);
                } catch (NotSupportedException e) {  // The "Ttl" property can be set only for sockets in the InterNetwork or InterNetworkV6 families
                    Console.WriteLine("NotSupportedException while defining Socket properties. :: " + e.Message);
                }


                return s;
            } catch (SocketException e) {  // An error occurred when attempting to access the socket.
                Console.WriteLine("SocketException while this server tried ACCEPT client request for connection. :: " + e.Message);
            } catch (ObjectDisposedException e) {  // Socket has been closed.
                Console.WriteLine("ObjectDisposedException while this server tried ACCEPT client request for connection. :: " + e.Message);
            } catch (InvalidOperationException e) { // The accepting socket is not listening for connections. Call 'Bind(EndPoint)' and 'Listen(Int32)' methods before calling 'Accept()'.
                Console.WriteLine("InvalidOperationException while this server tried ACCEPT client request for connection. :: " + e.Message);
            }

            return null;
        }


        public int ServerRECEIVE(Socket sock, string msgtxt, int buffersize = 1500, UTF8Encoding enc = null) {
            // The default value for 'buffersize' is the Maximum Ethernet Payload Size, i.e. 1500 octets (plus a 30 octets header).

            // To ensure that encoded bytes are decoded properly, you should use a Unicode encoding, such as 
            // UTF8Encoding or UnicodeEncoding. You could also use a higher-level protocol to ensure that the
            // same format is used for encoding and decoding.
            if (enc == null) { enc = new UTF8Encoding(); }  // If no Encoding is passed to parmeter 'enc', create the UTF8 enconding is applied.
            byte[] bytemsg = new byte[buffersize];
            int bytesrec = ServerRECEIVE(sock, bytemsg);
            msgtxt = null;
            try {
                msgtxt = enc.GetString(bytemsg);  // Encode the data string into a byte array.
            } catch (ArgumentNullException e) {
                Console.WriteLine("ArgumentNullException while this Server was enconding received data from Client. " + e.Message);
            } catch (DecoderFallbackException e) {
                Console.WriteLine("DecoderFallbackException while this Server was enconding received data from Client. " + e.Message);
            } catch (ArgumentException e) {
                Console.WriteLine("ArgumentException while this Server was enconding received data from Client. " + e.Message);
            }
            return msgtxt.Length;
        }


        public int ServerRECEIVE(Socket sock, byte[] msg, int amountMax = int.MinValue, int init_ix = int.MinValue) {
            // A initial negative value (int.MinValue) is used as a flag to indicate default values on optional parameters.
            if (init_ix == int.MinValue) { init_ix = 0; }  // Default value to init_ix is to fill all 'msg' elements  with received data, starting at index 0. 
            if (amountMax == int.MinValue) { amountMax = (msg?.Length ?? 0); }  // Default value to amountMax is to fill all 'msg' elements  with received data. 

            int bytesRead = -1;  // Number of bytes retrieved from (Network Interface Card) reception buffer in the last call of 'sock.Receive()'.
                                 // A initial negative value is used to start the "while ((totalReceiv < amountMax) && (bytesRead!=0)){}" loop.
            int totalReceiv = 0; // Total number of bytes retrieved from (Network Interface Card) reception buffer in a single call to 'ServerRECEIVE()' method, independently of the number of calls to 'sock.Receive()'.
                                 // In TCP protocol, when a data block is divided in many packets, the 'Receive()' 
                                 //     method may return only one part of sent data block, because not all packets has 
                                 //     been received by network interface card at the time 'Receive()' was called.
            SocketError sockError = SocketError.Fault;
            int remain = 0; // Amount of bytes that was not retrieved from the queue of socket. Must be a nullable integer because "remain = sock.Available;" can throw an Exception.
            int countReceivCall = 0; // Number of times that "sock.Receive()" was called.
            int receiveRetry = 0;   // Number of times that "sock.Receive()" returned zero value, allowing to implement a customized time-out.

            try {
            
                // If "Socket.Blocking" is 'true' (blocking mode) and no data is available for reading, the 
                //     'Receive()' method will block until data is available, unless a time-out value was set 
                //     by using 'Socket.ReceiveTimeout()'.  If time-out expires, 'Receive()' method will throw
                //     'SocketException'.
                // If "Socket.Blocking" is 'false' (non-blocking mode), and there is no data available in the in
                //     the protocol stack buffer, the 'Receive()' method will complete (its execution thread) 
                //     immediately and throw a 'SocketException'.

                Console.WriteLine("\t#About to start to reveice data:\n\t\tServiceClientSockets.Blocking:= {0};\n\t\tBuffer size (amountMax):= {1};" +
                                  "\n\t\tBuffer initial index position (init_ix):= {2};\n\t\tAvailable data (remain):= {3}",
                                  sock.Blocking, amountMax, init_ix, remain.ToString()); // Used only for tests puposes.

                while (totalReceiv < amountMax)  { // ((totalReceiv < amountMax) && (bytesRead != 0)) { // this while loop is intended only for situations when 'Socket.Blocking' property is set to 'false'. 
                    bool retry;  // flag to avoid to check same condition twice, inside customized time-out algorithm;
                    do { // This loop gives a customized time-out of 'ReceiveReTryLim' (iterations) x 'ReceiveReTryInterval' (miliseconds of 'Sleep()') to wait for arraival of all 'amountMax' data bytes that this server hopes to receive.
                        try {
                            remain = sock.Available; // Return the amount of data that has been received from the 
                                 // (bound host, specified in 'Connect()' or by 'Accept()' methods) and still is
                                 // available to be read, i.e. was not retrieved from network card interface yet.
                                 // The access to 'Available' property may throw 'SocketException' or 'ObjectDisposeException'.
                        } catch (Exception e) {
                            Console.WriteLine("\t***Impossible to check received data (from Client) in this Service buffer queue. " + e.Message);
                            remain = 0;
                        }
                        retry = (remain == 0) && (receiveRetry < ReceiveReTryLim);
                        if (retry) {
                            Thread.Sleep(ReceiveReTryInterval);
                            ++receiveRetry;
                        }
                    } while (retry);
                    if (remain == 0) {   // ... and also "(receiveRetry >= ReceiveReTryLim)"
                        Console.WriteLine("\t%%% Customized Receive Time-Out for this Server expired after {0} seconds of waiting.", ReceiveReTryLim * ReceiveReTryInterval / 1000);
                        break;
                    //} else {
                    //    // receiveRetry = 0;  // Reset 'receiveRetry' every time that arrive any data in reception buffer.
                    //    receiveRetry = ReceiveReTryLim;  // Deactivate customized time-out after call 'ClientSocket.Receive()'.
                    }
                    bytesRead = sock.Receive(msg, init_ix + totalReceiv, amountMax - totalReceiv, SocketFlags.None, out sockError);
                    // Receives data from a bound Socket and returns the amount of bytes received.
                    // The size of data to be send must not exceed the maximum packet size of the underlying service provider, or the datagram will not be sent and a 'SocketException' will thrown. 

                    // In connection-oriented protocol (TCP), 'Receive()' method will read all available data,
                    //     up to the number of bytes in size parameter. If the remote host (server) calls 
                    //     'Shutdown()' method (to shut down the connection), and all (old) available data has already 
                    //     been received, 'Receive()' method will complete (its execution thread) immediately and
                    //     return zero bytes.
                    // In a connectionless protocol (UDP), 'Receive()' method will read the first queued 
                    //     datagram from the destination address specified in 'Connect()' method. If received
                    //     datagram is larger than buffer parameter size, buffer is filled with the first part
                    //     of the datagram message, the excess data is lost and a 'SocketException' is thrown. 

                    totalReceiv += bytesRead;

                    Console.WriteLine("\t#ServiceClientSocket[x].Receive() called by x {0} time." +
                                  "\n\t\tbytesRead:= {1};\n\t\ttotalReceiv:= {2};\n\t\tremain:= {3}" +
                                  "\n\t\tSocketError:= {4}",
                                  ++countReceivCall, bytesRead, totalReceiv, remain.ToString(), sockError.ToString()); // Used only for tests puposes.

                    if (sockError == SocketError.Success) {
                        if (totalReceiv == amountMax) {
                            Console.WriteLine("\t***This Server retrieved SUCCESSFULLY ALL requested data from Client.");  // ("\nThis Server received ALL required data from Client, SUCCESSFULLY.");
                            if (remain > 0)
                                Console.WriteLine("\t***There is more available data (from Client) to be retrieved by the Server: {0} bytes.", remain); // ("\nThis Server has more data, received from Client, that still was not read: {0} bytes.", remain);
                        } else {  // This possiblility may happen if 'Socket.Blocking' property is set to 'false' or time-out expire or data block sent is greater than receiver device buffer. 
                            Console.WriteLine("\t***This Server received PART of requested data from Client: {0} bytes FROM a total requested of {1}.",
                                              totalReceiv, amountMax);
                        }
                    } else {
                        if (totalReceiv != amountMax) {
                            Console.WriteLine("\n\t***This Server received PART of requested data from Client with error '{0}'; {1} bytes FROM a total requested of {2}.",
                                              sockError.ToString(), totalReceiv, amountMax);
                        } else {  // I (Vinicius) am not sure if this situation ( (ClientSocketError != SocketError.Success) && (bytesSent == payload.Length) may happen. 
                            Console.WriteLine("\n\t%%% Although this Server read all requested data from Client, there was an error '{0}'.", sockError.ToString());
                        }
                        break;
                    }
                }
            } catch (SocketException e) {  // An error occurred when attempting to access the socket. The time while 'Socket.Receive()' blocks (program execution) waiting for data arraival exceeded 'Socket.ReceiveTimeout' property. The 'socketFlags' argument is not a valid combination of values. The 'LocalEndPoint' property is not set. 
                // Use the 'SocketException.ErrorCode' property to obtain the specific error code. Refer to the
                //     "Windows Sockets" version 2 API error code documentation in the MSDN library for a detailed
                //     description of the error.
                Console.WriteLine("SocketException while this Server was Receiving data from Client.  :: " + e.Message + "\n\t\tSocketException.ErrorCode = " + e.ErrorCode);
            } catch (ObjectDisposedException e) {  // Socket has been closed.
                Console.WriteLine("ObjectDisposedException while this Server was Receiving data from Client. :: " + e.Message);
            } catch (ArgumentOutOfRangeException e) { // The value of the starting index or the amount of data to be received is not valid.
                Console.WriteLine("ArgumentOutOfRangeException while this Server was Receiving data from Client. ::  :: " + e.Message);
            } catch (ArgumentNullException e) {  // The buffer (byte array) is null.
                Console.WriteLine("ArgumentNullException while this Server was Receiving data from Client. ::  :: " + e.Message);
            } catch (SecurityException e) { // A caller higher in the call stack does not have permission for the requested operation.
                Console.WriteLine("SecurityException while Connecting this Server to a Client. ::  :: " + e.Message);
            }

            try {
                remain = sock.Available; // May throw 'SocketException' or 'ObjectDisposeException'.
            } catch (Exception) {
                Console.WriteLine("\n\t%%% It was not possible to determine if STILL there is some data (from Client) to be retrieved to this server.");
                remain = -1;
            }
            Console.WriteLine("\t### Final results from ServerRECEIVE():\n\t\tServiceClientSocket[x].Receive() called by x {0} time." +
                          "\n\t\ttotalReceiv:= {1};\n\t\tremain:= {2};\n\t\tSocketError:= {3}",
                          countReceivCall, totalReceiv, remain, sockError.ToString()); // Used only for tests puposes.

            return totalReceiv;
        }

  
        public int ServerSEND(Socket sock, string msg, UTF8Encoding enc = null) {
            // To ensure that encoded bytes are decoded properly, you should use a Unicode encoding, such as 
            // UTF8Encoding or UnicodeEncoding. You could also use a higher-level protocol to ensure that the
            // same format is used for encoding and decoding.
            if (enc == null) { enc = new UTF8Encoding(); }  // If no Encoding is passed to parmeter 'enc', create the UTF8 enconding is applied.
            byte[] bytemsg = null;
            try {
                bytemsg = enc.GetBytes(msg);  // Encode the data string into a byte array.
            } catch (ArgumentNullException e) {
                Console.WriteLine("ArgumentNullException while this Server was enconding received data from Client. " + e.Message);
            } catch (DecoderFallbackException e) {
                Console.WriteLine("DecoderFallbackException while this Server was enconding received data from Client. " + e.Message);
            }
            return ServerSEND(sock, bytemsg);
        }


        public int ServerSEND(Socket sock, byte[] payload, int amount = int.MinValue, int init_ix = int.MinValue) {
            // A initial negative value (int.MinValue) is used as a flag to indicate default values.
            if (init_ix == int.MinValue) { init_ix = 0; }  // Default value to init_ix is to send all 'payload' data, starting at index 0. 
            if (amount == int.MinValue) { amount = payload.Length; }  // Default value to amount is to send all 'payload' data. 

            int bytesSent = 0;  // Number of bytes sent in the last call of 'sock.Send()'.
            int totalSent = 0;  // Total number of bytes sent by a single call of this method ( 'ServerSEND()' ), independently of how many times the method 'sock.Send()' were call inside it.
            int countSendCall = 0;   // Number of times that method 'sock.Send()' were called inside single call of 'ServerSEND()'.
            int sendRetry = 0;  // Count the number of times that method 'sock.Send()' returned value zero inside a single call of 'ServerSEND()', to create a customized time-out.
            SocketError ServiceClientSocketError = SocketError.Fault;

            Console.WriteLine("\t#About to start to send data:\n\t\tServiceClientSockets.Blocking:= {0};\n\t\tAmount of data to send (amount):= {1};" +
                          "\n\t\tBuffer initial index position (init_ix):= {2}.", sock.Blocking, amount, init_ix); // Used only for tests puposes.

            try {
                while (totalSent < amount) { // this while loop is intended only for situations when 'Socket.Blocking' property is set to 'false'. 
                    bool retry;
                    do {
                        // If client's socket receiver buffer is full and this Server calls 'socket.Send()' one more time after it,
                        // the amount of sent bytes will be '0'. To minimize this sort of problem, by providing a "secodn level" of
                        // time-out (beyond 'sock.SendTimeout' ) this 'while((bytesSent==0) && (sendRetry < SendReTryLim))' loop
                        // was implemented.

                        bytesSent = sock.Send(payload, init_ix + totalSent, amount - totalSent, SocketFlags.None, out ServiceClientSocketError);
                        // Send the data through the socket and returns the number of bytes that were successfully sent.
                        // The size of data to be send must not exceed the maximum packet size of the underlying service provider, or the datagram will not be sent and a 'SocketException' will thrown. 
                        // In connection-oriented protocol (TCP), 'Send()' will block until the requested number of bytes are sent,
                        //     unless a time-out was set by using 'Socket.SendTimeout'. If the time-out value was exceeded,
                        //     the Send call will throw a SocketException. In nonblocking mode, 'Send()' may complete successfully
                        //     even if it sends less data than the number of bytes you request. It is your application's
                        //     responsibility to keep track of the number of bytes sent and to retry the operation until
                        //     the application sends the requested number of bytes.
                        // A successful completion of the 'Send()' method means that the underlying system has had room to buffer
                        //     your data for a network send. So, the successful completion of a send does not indicate that the
                        //     data was successfully delivered.
                        totalSent += bytesSent;

                        Console.WriteLine("\t***ServiceClientSockets.Send() called by x {0} time.\n\t\tbytesSent:= {1};" +
                                              "\n\t\ttotalSent:= {2};\n\t\tServiceClientSocketError:= {3}",
                                              ++countSendCall, bytesSent, totalSent, ServiceClientSocketError.ToString()); // Used only for tests puposes.
                        retry = (bytesSent == 0) && (sendRetry < SendReTryLim);
                        if (retry) {
                            Thread.Sleep(SendReTryInterval);
                            ++sendRetry;
                        }
                    } while (retry);
                    if (bytesSent == 0) {   // ...and also (sendRetry >= SendReTryLim)
                        Console.WriteLine("\t%%% The Customized Send Time-Out of this Server had expired." +
                                          " Total bytes sent: {0}", bytesSent);
                        break;
                    }
                    if (ServiceClientSocketError == SocketError.Success) {
                        if (totalSent == amount) {
                            Console.WriteLine("\t***ALL data were SUCCESSFULLY sent from this Server to Client.");
                        } else {  // This possiblility may happen if 'Socket.Blocking' property is set to 'false'. 
                            Console.WriteLine("\t***Only a PART of data block from this Server was sent to the Client: {0} bytes FROM {1}.",
                                              totalSent, amount);
                            continue; // Give another chance to send all data.
                        }
                    } else {
                        if (totalSent != amount) {
                            Console.WriteLine("\t***A SENT from Server to Client happened with error '{0}', and {1} bytes FROM a total of {2} had been sent.",
                                              ServiceClientSocketError.ToString(), totalSent, amount);
                        } else {  // I (Vinicius) am not sure if this situation ( (ServiceClientSocketError != SocketError.Success) && (bytesSent == payload.Length) may happen. 
                            Console.WriteLine("\t%%% Although all data were successfully sent from Server to Client, there was an error '{0}'.",
                                              ServiceClientSocketError.ToString());
                        }
                        break;
                    }

                }
            } catch (SocketException e) {  // An error occurred when attempting to access the socket. The 'SocketFlags' argument is not a valid combination of values. 
                // Use the 'SocketException.ErrorCode' property to obtain the specific error code. Refer to the
                //     "Windows Sockets" version 2 API error code documentation in the MSDN library for a detailed
                //     description of the error.
                Console.WriteLine("SocketException while Sending data from client to server. :: " + e.Message + "\n\t\tSocketException.ErrorCode = " + e.ErrorCode);
            } catch (ObjectDisposedException e) {  // Socket has been closed.
                Console.WriteLine("ObjectDisposedException while Sending data from client to server. :: " + e.Message);
            } catch (ArgumentOutOfRangeException e) { // The value of the starting index or the amount of data to be send is not valid.
                Console.WriteLine("ArgumentOutOfRangeException while Sending data from client to server. :: " + e.Message);
            } catch (ArgumentNullException e) {  // The buffer (byte array) is null.
                Console.WriteLine("ArgumentNullException while Sending data from client to server. :: " + e.Message);
            } catch (ArgumentException e) {  // The buffer (byte array) is empty.
                Console.WriteLine("ArgumentException while Sending data from client to server. :: " + e.Message);
            }

            Console.WriteLine("\t###Final results from ServerSEND():\n\t\tServiceClientSockets.Send() called by x {0} time.;" +
                          "\n\t\ttotalSent:= {1};\n\t\tServiceClientSocketError:= {2}", countSendCall, totalSent, ServiceClientSocketError.ToString());  // Used only for tests puposes.


            return totalSent;
        }

        
        public void ServerReleaseClientComm(Socket serviceClientSocket) {
            // Release the Socket
            try {
                serviceClientSocket.Shutdown(SocketShutdown.Both);
                // In a connection-oriented protocol (TCP), always call the 'Shutdown()' method before closing the
                //     Socket to ensure that all data is sent and received on the connected socket before it is closed.
                //     Using 'Shutdown()' on a connectionless protocol is not recommended.
            } catch (SocketException e) { // An error occurred when attempting to access the socket.
                Console.WriteLine("SocketException while Shuting Down Client socket:  :: " + e.Message);
            } catch (ObjectDisposedException e) { // The Socket has been closed.
                Console.WriteLine("ObjectDisposedException while Shuting Down Client socket:  :: " + e.Message);
            }

            // There is two options to close the socket: 'Close()' either 'Disconnect()'.
            //     'Close()' will NOT allow reuse of socket and will NOT throw Exceptions;
            //     'Disconnect()' allows REUSE of socket, but may throw Exceptions.

            /*     try {
                       serviceClientSocket.Disconnect(true);
                       // A connection-oriented protocol, you can use this method to close the socket. This method ends
                       //     the connection and sets the Connected property to false. However, if method's argument  
                       //     is 'true', the socket can be reused.
                       if (ClientSocket.Connected) { Console.WriteLine("We're still connnected");
                       } else { Console.WriteLine("We're disconnected"); }
                    } catch (PlatformNotSupportedException e) {  // This method requires Windows 2000 or earlier, or the exception will be thrown.
                       Console.WriteLine("PlatformNotSupportedException while Disconnecting the client socket:  :: " + e.Message)
                    } catch (SocketException e) { // An error occurred when attempting to access the socket.
                        Console.WriteLine("SocketException while Shuting Down Client socket:  :: " + e.Message);
                    } catch (ObjectDisposedException e) { // The Socket has been closed.
                        Console.WriteLine("ObjectDisposedException while Shuting Down Client socket:  :: " + e.Message);
                   }  
            */
            serviceClientSocket.Close();
            // Closes the Socket connection and releases all associated resources with a specified timeout to allow
            //     queued data to be sent.
            // If it needs to call 'Close(time-out)' without first calling 'Shutdown()', it is possible to ensure that data
            //     queued for outgoing transmission will be sent by setting the 'DontLinger' option to 'false' and
            //     specifying a non-zero time-out interval. The 'Close(time-out)' will then block until this data is sent
            //     or until the specified time-out expires.  Time-out argument is in seconds. If you set 'DontLinger' to 
            //     'false' and specify a zero time-out interval, 'Close(0)' releases the connection and 
            //     automatically discards outgoing queued data.


            /* No MS Docs example calls 'serviceClientSocket.Dispose()'. It releases the unmanaged resources used by the Socket, 
            //     and optionally disposes of the managed resources. If argument is 'true' this method releases both 
            //     managed and unmanaged resources; if it is 'false' the method releases only unmanaged resources.
            // After calling 'Dispose()', you must release all references to the Socket so the garbage collector 
            //     can reclaim the memory area occuped by the Socket.
            */

        }


        public void ServerReleaseListening() {
            // Release the Socket
            // To release the server listenning socket, the methods 'Socket.Shutdown()' and 'Socket.Disconnect()'
            // can NOT be used.

            ServiceListeningSocket.Close();
            // Closes the Socket connection and releases all associated resources with a specified timeout to allow
            //     queued data to be sent.
            // If it needs to call 'Close(time-out)' without first calling 'Shutdown()', it is possible to ensure that data
            //     queued for outgoing transmission will be sent by setting the 'DontLinger' option to 'false' and
            //     specifying a non-zero time-out interval. The 'Close(time-out)' will then block until this data is sent
            //     or until the specified time-out expires.  Time-out argument is in seconds. If you set 'DontLinger' to 
            //     'false' and specify a zero time-out interval, 'Close(0)' releases the connection and 
            //     automatically discards outgoing queued data.

            // ServiceListeningSocket.Dispose();
            /* No MS Docs example calls 'serviceClientSocket.Dispose()'. It releases the unmanaged resources used by the Socket, 
            //     and optionally disposes of the managed resources. If argument is 'true' this method releases both 
            //     managed and unmanaged resources; if it is 'false' the method releases only unmanaged resources.
            // After calling 'Dispose()', you must release all references to the Socket so the garbage collector 
            //     can reclaim the memory area occuped by the Socket.
            */

        }


    }


    class Program {

        static void Main(string[] args) {

            string opemode;
            char cm = 'a';

            do { // this block is just intended to allow user to choose  his/her mmachine operation mode "server" either "client", at run time.
                Console.WriteLine("Choose an option: \n\t\"1\" for SERVER;\n\t\"2\" for CLIENT.");
                try {
                    opemode = Console.ReadLine();  // Try: "Enter" key, white spaces, "hostname" (for throw exception), "localhost", "127.0.0.1", "www.google.com.br" , "8.8.8.8" (it is the Google's DNS Server address), etc.
                } catch (Exception) {
                    opemode = null;
                }

                if ((opemode != null) && (opemode.Trim() != string.Empty)) {
                    cm = opemode.Trim()[0];
                }
            } while ((cm != '1') && (cm != '2'));

            if (cm == '1') {
                TCP_Server_Sync Server_listener = new TCP_Server_Sync();
            } else {
                TCP_Client_Sync Client_requester = new TCP_Client_Sync();
            }


            Console.WriteLine("\n\n\nPress any key to close the window!");
            Console.ReadKey(true);
        }


    }


    public static class DNS_Resolver {

        public static IPAddress[] Call_DNS_Resolver(string hostnm) {

            IPAddress[] ipaddrss = null;

            if ((hostnm == null) || (hostnm.Trim() == string.Empty)) { // If 'hostnm' is null or empty string, get the name of the local machine (i.e., computer that is running this program).
                try {
                    hostnm = Dns.GetHostName(); // This is necessary to operation mode "Server" work with other computers, intead of just work with loopback.
                } catch (Exception e) {
                    Console.WriteLine("Exception. Source: " + e.Source + " ; Message :  :: " + e.Message);
                } finally {
                    if (hostnm == null) hostnm = "127.0.0.1"; // If there is an error while getting local machine host name, use name of Loopback IP address (127.0.0.1).
                }
            }

            try {
                ipaddrss = Dns.GetHostAddresses(hostnm);
            } catch (Exception e) {
                Console.WriteLine("Exception. Source: {0} ; Message: {1}", e.Source, e.Message);
            } finally {
                if ((ipaddrss?.Length ?? 0) == 0) {  // Only for the case of an Exception being thrown.
                    ipaddrss = new IPAddress[] { IPAddress.Parse("127.0.0.1") };  // Set IPAddress array to one element with LoopBack IP address (127.0.0.1).
                }
            }

            return ipaddrss;
        }

    }



}


/*
#region "SERVER Socket Synchronous Example"

// https://docs.microsoft.com/en-us/dotnet/framework/network-programming/synchronous-server-socket-example
// technical reference: https://docs.microsoft.com/en-us/dotnet/framework/network-programming/listening-with-sockets
//            https://docs.microsoft.com/en-us/dotnet/framework/network-programming/using-a-synchronous-server-socket
//            https://docs.microsoft.com/en-us/dotnet/framework/network-programming/using-an-asynchronous-server-socket

// The following example program creates a server that receives connection requests from clients. The server is
// built with a synchronous socket, so execution of the server application is suspended while it waits for a
// connection from a client. The application receives a string from the client, displays the string on the console,
// and then echoes the string back to the client. The string from the client must contain the string "<EOF>" to 
//signal the end of the message.

using System;  
using System.Net;  
using System.Net.Sockets;  
using System.Text;  

public class SynchronousSocketListener {  

    // Incoming data from the client.  
    public static string data = null;  

    public static void StartListening() {  
        // Data buffer for incoming data.  
        byte[] bytes = new Byte[1024];  

        // Establish the local endpoint for the socket.  
        // Dns.GetHostName returns the name of the   
        // host running the application.  
        IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());  
        IPAddress ipAddress = ipHostInfo.AddressList[0];  
        IPEndPoint localEndPoint = new IPEndPoint(ipAddress, 11000);  

        // Create a TCP/IP socket.  
        Socket listener = new Socket(ipAddress.AddressFamily,  
            SocketType.Stream, ProtocolType.Tcp );  

        // Bind the socket to the local endpoint and   
        // listen for incoming connections.  
        try {  
            listener.Bind(localEndPoint);  
            listener.Listen(10);  

            // Start listening for connections.  
            while (true) {  
                Console.WriteLine("Waiting for a connection...");  
                // Program is suspended while waiting for an incoming connection.  
                Socket handler = listener.Accept();  
                data = null;  

                // An incoming connection needs to be processed.  
                while (true) {  
                    int bytesRec = handler.Receive(bytes);  
                    data += Encoding.ASCII.GetString(bytes,0,bytesRec);  
                    if (data.IndexOf("<EOF>") > -1) {  
                        break;  
                    }  
                }  

                // Show the data on the console.  
                Console.WriteLine( "Text received : {0}", data);  

                // Echo the data back to the client.  
                byte[] msg = Encoding.ASCII.GetBytes(data);  

                handler.Send(msg);  
                handler.Shutdown(SocketShutdown.Both);  
                handler.Close();  
            }  

        } catch (Exception e) {  
            Console.WriteLine(e.ToString());  
        }  

        Console.WriteLine("\nPress ENTER to continue...");  
        Console.Read();  

    }  

    public static int Main(String[] args) {  
        StartListening();  
        return 0;  
    }  
}  


#endregion
*/

/*
#region "CLIENT Socket Synchronous Example"

// https://docs.microsoft.com/en-us/dotnet/framework/network-programming/synchronous-client-socket-example
// technical reference: https://docs.microsoft.com/en-us/dotnet/framework/network-programming/using-client-sockets
//            https://docs.microsoft.com/en-us/dotnet/framework/network-programming/using-an-asynchronous-client-socket
//            https://docs.microsoft.com/en-us/dotnet/framework/network-programming/using-a-synchronous-client-socket

// The following example program creates a client that connects to a server. The client is built with a synchronous socket,
// so execution of the client application is suspended until the server returns a response. The application sends a string
// to the server and then displays the string returned by the server on the console.

using System;  
using System.Net;  
using System.Net.Sockets;  
using System.Text;  

public class SynchronousSocketClient {  

    public static void StartClient() {  
        // Data buffer for incoming data.  
        byte[] bytes = new byte[1024];  

        // Connect to a remote device.  
        try {  
            // Establish the remote endpoint for the socket.  
            // This example uses port 11000 on the local computer.  
            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());  
            IPAddress ipAddress = ipHostInfo.AddressList[0];  
            IPEndPoint remoteEP = new IPEndPoint(ipAddress,11000);  

            // Create a TCP/IP  socket.  
            Socket sender = new Socket(ipAddress.AddressFamily,   
                SocketType.Stream, ProtocolType.Tcp );  

            // Connect the socket to the remote endpoint. Catch any errors.  
            try {  
                sender.Connect(remoteEP);  

                Console.WriteLine("Socket connected to {0}",  
                    sender.RemoteEndPoint.ToString());  

                // Encode the data string into a byte array.  
                byte[] msg = Encoding.ASCII.GetBytes("This is a test<EOF>");  

                // Send the data through the socket.  
                int bytesSent = sender.Send(msg);  

                // Receive the response from the remote device.  
                int bytesRec = sender.Receive(bytes);  
                Console.WriteLine("Echoed test = {0}",  
                    Encoding.ASCII.GetString(bytes,0,bytesRec));  

                // Release the socket.  
                sender.Shutdown(SocketShutdown.Both);  
                sender.Close();  

            } catch (ArgumentNullException ane) {  
                Console.WriteLine("ArgumentNullException : {0}",ane.ToString());  
            } catch (SocketException se) {  
                Console.WriteLine("SocketException : {0}",se.ToString());  
            } catch (Exception e) {  
                Console.WriteLine("Unexpected exception : {0}", e.ToString());  
            }  

        } catch (Exception e) {  
            Console.WriteLine( e.ToString());  
        }  
    }  

    public static int Main(String[] args) {  
        StartClient();  
        return 0;  
    }  
}  

#endregion
*/


