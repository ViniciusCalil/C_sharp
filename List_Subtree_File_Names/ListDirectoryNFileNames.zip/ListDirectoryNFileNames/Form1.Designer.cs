﻿namespace DirectoryFileNames
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txBx_Directory = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_ReadDir = new System.Windows.Forms.Button();
            this.txBx_Out = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.bt_Search = new System.Windows.Forms.Button();
            this.ckBx_SudDir = new System.Windows.Forms.CheckBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txBx_Directory
            // 
            this.txBx_Directory.Location = new System.Drawing.Point(12, 51);
            this.txBx_Directory.Multiline = true;
            this.txBx_Directory.Name = "txBx_Directory";
            this.txBx_Directory.Size = new System.Drawing.Size(563, 20);
            this.txBx_Directory.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(297, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Base Directory's complete name where the desired files are:";
            // 
            // bt_ReadDir
            // 
            this.bt_ReadDir.Location = new System.Drawing.Point(266, 109);
            this.bt_ReadDir.Name = "bt_ReadDir";
            this.bt_ReadDir.Size = new System.Drawing.Size(95, 23);
            this.bt_ReadDir.TabIndex = 2;
            this.bt_ReadDir.Text = "Read directory";
            this.bt_ReadDir.UseVisualStyleBackColor = true;
            this.bt_ReadDir.Click += new System.EventHandler(this.button1_Click);
            // 
            // txBx_Out
            // 
            this.txBx_Out.Location = new System.Drawing.Point(18, 157);
            this.txBx_Out.Multiline = true;
            this.txBx_Out.Name = "txBx_Out";
            this.txBx_Out.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txBx_Out.Size = new System.Drawing.Size(621, 374);
            this.txBx_Out.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 138);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Directory Contents:";
            // 
            // bt_Search
            // 
            this.bt_Search.Location = new System.Drawing.Point(581, 51);
            this.bt_Search.Name = "bt_Search";
            this.bt_Search.Size = new System.Drawing.Size(58, 23);
            this.bt_Search.TabIndex = 5;
            this.bt_Search.Text = "Search";
            this.bt_Search.UseVisualStyleBackColor = true;
            this.bt_Search.Click += new System.EventHandler(this.bt_Search_Click);
            // 
            // ckBx_SudDir
            // 
            this.ckBx_SudDir.AutoSize = true;
            this.ckBx_SudDir.Location = new System.Drawing.Point(23, 80);
            this.ckBx_SudDir.Name = "ckBx_SudDir";
            this.ckBx_SudDir.Size = new System.Drawing.Size(161, 17);
            this.ckBx_SudDir.TabIndex = 6;
            this.ckBx_SudDir.Text = "Search all subtree.";
            this.ckBx_SudDir.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(661, 24);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(50, 20);
            this.toolStripMenuItem1.Text = "Help";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.Menu_About);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(661, 543);
            this.Controls.Add(this.ckBx_SudDir);
            this.Controls.Add(this.bt_Search);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txBx_Out);
            this.Controls.Add(this.bt_ReadDir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txBx_Directory);
            this.Controls.Add(this.menuStrip1);
            this.HelpButton = true;
            this.MainMenuStrip = this.menuStrip1;
            this.MaximumSize = new System.Drawing.Size(677, 581);
            this.MinimumSize = new System.Drawing.Size(677, 581);
            this.Name = "Form1";
            this.Text = "Show the contents of a Directory.";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private void AboutIt() {
            System.Windows.Forms.MessageBox.Show(
                "\tDate: 2019/01/23\n" + 
                "\tAuthor: Vinicius D S Calil.\n\n" + 
                "Objective: retrieve a string containing the name of all files and " + 
                "subdirectories under a selected (Base) Directory. It is also possible to " + 
                "include the name of all files and subdirectories from all subdirectories  " +
                "under the Base Directory.\n\n\n" + 
                "Usage: \n" +
                "Click in 'Search', select the base directory where desired files (and  " +
                "subdirectories) are, then click 'OK'. " + 
                "Click in 'Read directory' to retrieve the names. If you wish to include " + 
                "all content of the subtree, check the option 'Search all sub-tree' " + 
                "before click in 'Read directory'.\n\n" + 
                "Note: if the subtree is too big or has too many files, the application " + 
                "will seems to be frozen for a while.",
                "Information about this program.",  System.Windows.Forms.MessageBoxButtons.OK,
                 System.Windows.Forms.MessageBoxIcon.Exclamation);
        } 
        private System.Windows.Forms.TextBox txBx_Directory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_ReadDir;
        private System.Windows.Forms.TextBox txBx_Out;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button bt_Search;
        private System.Windows.Forms.CheckBox ckBx_SudDir;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
    }
}

