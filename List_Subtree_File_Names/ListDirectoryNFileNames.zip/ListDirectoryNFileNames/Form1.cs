﻿using System;
using System.Windows.Forms;
using System.IO;

namespace DirectoryFileNames {
    public partial class Form1 : Form {
        public Form1() {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) {
            string DirName = txBx_Directory.Text;
            if ((DirName == null) || (DirName.Trim() == string.Empty))
                MessageBox.Show("No name or an invalid one was entered for the Base Directory!","ERROR: invalid directory name.",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning );

            DirectoryInfo DirInfo = new DirectoryInfo(DirName);
            FileInfo[] Files = null;
            try {
                if (ckBx_SudDir.Checked == true ) {
                    Files = DirInfo.GetFiles("*",SearchOption.AllDirectories);   // DirInfo.GetFiles("*.txt"); //Getting Text files
                } else {
                    Files = DirInfo.GetFiles("*", SearchOption.TopDirectoryOnly);   // DirInfo.GetFiles("*.txt"); //Getting Text files
                }
            } catch (Exception ex) {
                 MessageBox.Show("Make sure you really have Access Rights to the contents of all subdirectories\n" + ex.Message,
                     "ACCESS ERROR", MessageBoxButtons.OK, MessageBoxIcon.Warning );
                return;
            }
            string str = "     ------ Files list: -----     " + Environment.NewLine;
            if (Files.Length == 0)  {
                str += Environment.NewLine + 
                       "  ****** THIS DIRECTORY DOES NOT CONTAIN FILES!!! ******  " +
                       Environment.NewLine;
            } else {
                foreach(FileInfo file in Files ) {
                    str += file.Name + Environment.NewLine;
                }
            }

            str += Environment.NewLine + 
                   "-----===================================------" +
                   Environment.NewLine + Environment.NewLine;
            str +=   "     ------ Subdirectories List : -----     " + Environment.NewLine;
            DirectoryInfo[] SubDir = null;
            try {
                 if (ckBx_SudDir.Checked == true ) {
                     SubDir = DirInfo.GetDirectories("*",SearchOption.AllDirectories);
                 } else {
                     SubDir = DirInfo.GetDirectories("*", SearchOption.TopDirectoryOnly);
                 }
           } catch (Exception ex) {
                 MessageBox.Show("Make sure you really have Access Rights to the contents of all subdirectories\n" + ex.Message,
                     "ACCESS ERROR", MessageBoxButtons.OK, MessageBoxIcon.Warning );
                return;
            }
            if (SubDir.Length == 0)  {
                str += "\n  ****** THIS DIRECTORY DOES NOT CONTAIN SUBDIRECTORIES!!! ******  \n";
            } else {
                foreach(DirectoryInfo dir in SubDir ) {
                    str += dir.Name + Environment.NewLine;
                }
            }
            txBx_Out.Text = str;
        }

        private void button1_Click_1(object sender, EventArgs e) {
        }

        private void Menu_About(object sender, EventArgs e){
            AboutIt();
        }

        private void bt_Search_Click(object sender, EventArgs e) {
            FolderBrowserDialog folderBrowser = new FolderBrowserDialog();
            string folderName = null;

            DialogResult result = folderBrowser.ShowDialog();
            if( result == DialogResult.OK )
                folderName = folderBrowser.SelectedPath;

            txBx_Directory.Text = folderName;

        /*    
            OpenFileDialog FileBrowser = new OpenFileDialog() ;
            string filename = null;
            
            FileBrowser.InitialDirectory = folderName;
            FileBrowser.FileName = null;

            // Display the openFile dialog.
            DialogResult result = FileBrowser.ShowDialog();

            // OK button was pressed.
            if(result == DialogResult.OK) 
                filename = FileBrowser.FileName;
        */
        }
    }
}
